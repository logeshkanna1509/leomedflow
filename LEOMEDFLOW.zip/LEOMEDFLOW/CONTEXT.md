# Development context

This file is append-only. It records the implementation trajectory and is intended to let a new maintainer continue without reconstructing decisions.

## 2026-08-27 · Repository inspection and architecture

- Inspected `/home/stic/Desktop`; it was empty (no repository, instructions, runtime manifests or useful functionality to preserve).
- Available runtime was Python 3.12 standard library; Node/npm/pip and requested web packages were absent.
- Selected a dependency-light Python HTTP + SQLite WAL architecture with a versioned REST boundary. This makes the project runnable immediately and keeps mobile clients independent from the browser UI.
- Created `LEOMEDFLOW/` structure, environment configuration, database connection/transaction helpers and forward/rollback migration.

## 2026-08-27 · Database and security

- Added normalized tables for roles/users/tokens/operators, locations/customers, devices/consumables, quotations/invoices, jobs/allocations/schedules, shipments/collections, maintenance, proofs/notifications/attachments, custom definitions, inventory history, audits and import batches.
- Added unique serial/business identifiers, active-allocation and reporting indexes, foreign keys and immutable history/audit design.
- Implemented PBKDF2-SHA256 password hashing, constant-time verification, HMAC browser sessions, hashed bearer tokens, CSRF enforcement, login throttling, security headers, safe upload names, size/type/signature checks and environment-based secrets.

## 2026-08-27 · Business/API implementation

- Implemented live resource queries and Admin creation/edit endpoints for operators, inventory, customers, quotes and invoices.
- Implemented quote pricing/approval and one-time conversion to a duration-derived job, schedule and invoice.
- Added location/workload/status/maintenance/conflict-aware operator/device recommendations with future availability.
- Added overlap guards, audited manual overrides, explicit workflow state transitions, shipment/collection creation, operator notifications and complete inventory reconciliation.
- Added hashed proof and attachment storage, operator/job authorization, GPS validation, permanent serial/time/identity metadata and authorized downloads.
- Added CSV/XLSX imports with duplicate validation and row-level persistent error reports.
- Added filtered financial/operational BI, fleet utilization/downtime/revenue, workforce/customer/treatment/location breakdowns and collection turnaround.

## 2026-08-27 · User interfaces and demo

- Built a responsive visual system and connected single-page Admin/Operator portals in `templates/index.html`, `assets/app.css` and `assets/app.js`.
- Admin screens: Command Center, jobs, quotations/bills, collections, operators, devices/history, consumables, customers, BI, imports, audit and configuration.
- Operator screens: My Day, scoped assigned jobs, devices, consumables, collections, notifications, transitions and GPS proof upload.
- Added idempotent demo seed with real statuses/history and three demo identities. Added migration/rollback/seed/run/import scripts.

## 2026-08-27 · Verification and fixes

- Compiled all Python sources successfully and applied migration `001_initial`.
- Found/fixed a seed parameter mismatch while creating customer locations; confirmed the transaction rolled the failed attempt back cleanly.
- Found/fixed a mutation-response race by making writes durable before returning their HTTP response.
- Smoke-tested login, health, dashboard, analytics, device list and job detail through a running server.
- Added nine system tests covering authentication/password hashes, CSRF, permissions/scoping, CRUD/serial uniqueness, duration/conflicts/overrides, maintenance/allocation guards, complete workflow/proof/GPS/reconciliation, invalid transitions/GPS, imports and dashboard/BI calculations.
- First suite run found a device completion query selecting consumable-only `quantity`; fixed with a resource-specific projection. A test assertion was then corrected to compare SQLite rows by tuple.

## 2026-08-27 · Documentation and next steps

- Added README, architecture, database, API, procedures, migrations/import, credentials, deployment and handover documentation plus systemd/Nginx templates.
- Remaining external integrations and scale/security recommendations are listed in `HANDOVER.md` and `DEPLOYMENT.md`.
- Final verification pending at this entry: full regression suite, migration rollback/reapply on a disposable database, source/static checks and a clean-server smoke test.

## 2026-08-27 · Final verification

- Extended edit/manage coverage with audited device/consumable/customer/operator/quotation/invoice updates, operator password reset plus token revocation, invoice payment management and quotation/invoice document UI.
- Expanded BI filters to date, location, operator, device, consumable, customer, treatment and status; added delayed jobs, average treatment duration, operator completions, consumable contribution and device utilization/profit.
- Rebuilt the demo database after adding current-job and history location foreign keys. `PRAGMA foreign_key_check` reports zero errors.
- Verified migration forward → rollback (zero application tables) → forward on a disposable database, then rollback/reseeded the bundled demo database.
- Final `compileall` completed with no Python syntax errors.
- Final system suite: **10 tests passed in 11.157 seconds**. Coverage includes CSV and XLSX, documents, edits/history and password/token management in addition to the complete workflow/security/calculation scenarios above.
- Started a clean server on port 8092; confirmed Admin login and HTTP 200 for health, dashboard, device-filtered analytics, invoices and configuration. Headless Firefox loaded the HTML, CSS and JavaScript and executed the initial `/api/v1/me` call, confirming the browser bundle parsed and initialized.
- Confirmed seeded database: migration `001_initial`, 6 jobs and no foreign-key violations. Stopped all verification processes; normal startup remains `./scripts/run.sh`.

## 2026-08-27 · Portable systemd deployment and server migration

- Added an idempotent top-level `migrate.sh` server installer. It validates prerequisites, creates the unprivileged account, installs immutable code under `/opt/leomedflow`, keeps state under `/var/lib/leomedflow`, preserves existing destination state, imports SQLite through the backup API, copies uploads, generates/preserves protected production configuration, creates a pre-migration backup, validates integrity/foreign keys, installs/enables systemd, and leaves startup explicit.
- Added `migrate.sh --prepare-transfer` for a consistent snapshot of an installed live database, uploads and environment before securely copying the project folder to another server.
- Added `ExecStartPre` schema migration and additional systemd hardening. Fixed `ensure_directories()` so a redirected production database no longer tries to create a non-writable `/opt/leomedflow/instance` directory; this issue was found by the first real unprivileged deployment attempt.
- Added `/usr/local/bin/leomedflow-health`, which waits for startup and verifies systemd state plus HTTP, database/migration and upload readiness. Expanded `/health` and added regression coverage; the full suite now has 11 passing tests.
- Deployed successfully on this server using the migration script, then verified the required two-command contract: `systemctl start leomedflow` and `leomedflow-health` returned healthy for active service, migration `001_initial`, database and uploads.

## 2026-08-27 · Deployment completion record

- Ran the top-level `./migrate.sh` against the actual host, not only a disposable test environment. The first unprivileged migration exposed a stale source-tree assumption in `app/config.py`: `ensure_directories()` attempted to create `/opt/leomedflow/instance` even though production data was redirected to `/var/lib/leomedflow`. Changed it to create `DATABASE.parent`, then repeated the installation successfully.
- Confirmed the installer can be rerun against an existing installation without replacing its database, uploads, secret configuration or service identity. Each run stops an active old process before replacing code, creates a timestamped SQLite backup, reapplies only pending schema migrations, validates `PRAGMA integrity_check` and `PRAGMA foreign_key_check`, reloads/enables the systemd unit, and deliberately leaves the service stopped for the explicit startup command.
- Installed runtime code at `/opt/leomedflow`, persistent state at `/var/lib/leomedflow`, protected configuration at `/etc/leomedflow.env`, the unit at `/etc/systemd/system/leomedflow.service`, and the health command at `/usr/local/bin/leomedflow-health`. The service runs as the dedicated `leomedflow:leomedflow` account with read-only application code and writable access only to persistent state.
- Executed the required post-migration commands exactly: `systemctl start leomedflow` followed by `leomedflow-health`. The command exited successfully and reported systemd `active`, HTTP readiness, database `ok` at migration `001_initial`, and writable upload storage. The unit is enabled for boot and its journal contained no warnings from the deployment verification window.
- Exercised `/opt/leomedflow/migrate.sh --prepare-transfer` while the service was active. It stopped writes briefly, exported SQLite through the online backup API, copied uploads and the protected environment, restored the source service, and produced `/opt/leomedflow/transfer` with root-only permissions.
- Compared the live and transfer databases: both passed integrity checks, had zero foreign-key violations, and contained the same 6 jobs and 3 users. The final full regression suite passed all **11 tests**; Python compilation and shell syntax validation also completed successfully.
- Final destination-server contract: after securely copying the prepared project folder, run `sudo ./migrate.sh` once; ordinary application startup and verification then require only `systemctl start leomedflow` and `leomedflow-health`.

## 2026-08-27 · Static LAN deployment

- Identified the active VirtualBox interface as `enp0s3` with DHCP address `172.16.127.98/22`, gateway `172.16.124.1`, and DNS resolvers `96.45.45.45` and `96.45.46.46`.
- Added `/etc/netplan/99-leomedflow-static.yaml` using the NetworkManager renderer and persisted those exact values with DHCP disabled. `netplan generate --debug` succeeded before application; after `netplan apply`, NetworkManager reported IPv4 method `manual`, the route reported protocol `static`, DNS resolution remained active, and the interface retained `172.16.127.98/22`.
- Changed the installed production environment to `LEOMEDFLOW_HOST=0.0.0.0` so the service accepts LAN connections on TCP port 8080. Set `LEOMEDFLOW_COOKIE_SECURE=0` because this LAN deployment currently uses plain HTTP; it must be restored to `1` when HTTPS is configured.
- Restarted `leomedflow.service` and confirmed it is active and listening on `0.0.0.0:8080`. `leomedflow-health` passed, and direct requests through `http://172.16.127.98:8080/health` and `http://172.16.127.98:8080/` returned HTTP 200. No UFW, nftables, or iptables rules are installed on this host to block port 8080.
- Refreshed `/opt/leomedflow/transfer` after the network change. Its protected environment now carries `LEOMEDFLOW_HOST=0.0.0.0`, port `8080`, and the HTTP-compatible cookie setting, so a prepared server migration preserves LAN reachability.
- LAN clients should open `http://172.16.127.98:8080`. Because the selected address was originally issued by DHCP, reserve `172.16.127.98` for this VM in the LAN router/DHCP server to prevent a future address conflict. The VirtualBox adapter must remain attached to a network mode reachable by the LAN (normally bridged networking).

## 2026-08-27 · Final LAN status

- Final client URL: `http://172.16.127.98:8080`.
- Rechecked the static network after deployment: `enp0s3` retained `172.16.127.98/22`, the static default route through `172.16.124.1` remained active, and the gateway responded with zero packet loss.
- Rechecked LEOMEDFLOW after the network transition and transfer-snapshot refresh: systemd reported the service `active`, the application remained bound to all IPv4 interfaces on port `8080`, and an HTTP request to the LAN URL returned status 200.
- No host firewall rule is blocking TCP port 8080. Remaining infrastructure safeguard: reserve `172.16.127.98` in the upstream DHCP server and keep the VirtualBox NIC in a LAN-reachable mode.
