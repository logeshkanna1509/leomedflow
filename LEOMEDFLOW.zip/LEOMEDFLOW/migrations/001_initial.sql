PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS roles (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, permissions TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY, role_id INTEGER NOT NULL REFERENCES roles(id), username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL, display_name TEXT NOT NULL, email TEXT, active INTEGER NOT NULL DEFAULT 1,
  last_login_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS api_tokens (
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL, revoked_at TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS locations (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, address TEXT, district TEXT NOT NULL, state TEXT NOT NULL,
  country TEXT NOT NULL, latitude REAL, longitude REAL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS operators (
  id INTEGER PRIMARY KEY, user_id INTEGER UNIQUE REFERENCES users(id), employee_code TEXT NOT NULL UNIQUE,
  phone TEXT, availability_status TEXT NOT NULL DEFAULT 'Available', location_id INTEGER REFERENCES locations(id),
  max_concurrent_jobs INTEGER NOT NULL DEFAULT 3, skills TEXT NOT NULL DEFAULT '[]', custom_fields TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, email TEXT, phone TEXT,
  billing_location_id INTEGER REFERENCES locations(id), service_location_id INTEGER REFERENCES locations(id),
  custom_fields TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS devices (
  id INTEGER PRIMARY KEY, serial_number TEXT NOT NULL UNIQUE, model TEXT NOT NULL, category TEXT NOT NULL,
  status TEXT NOT NULL, location_id INTEGER REFERENCES locations(id), current_operator_id INTEGER REFERENCES operators(id),
  current_job_id INTEGER REFERENCES jobs(id), purchase_cost REAL NOT NULL DEFAULT 0, maintenance_due_at TEXT, custom_fields TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, retired_at TEXT
);
CREATE TABLE IF NOT EXISTS consumables (
  id INTEGER PRIMARY KEY, serial_number TEXT UNIQUE, sku TEXT NOT NULL, name TEXT NOT NULL, batch_number TEXT,
  quantity REAL NOT NULL DEFAULT 0, unit TEXT NOT NULL DEFAULT 'unit', unit_cost REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL, expiry_date TEXT, location_id INTEGER REFERENCES locations(id),
  current_operator_id INTEGER REFERENCES operators(id), current_job_id INTEGER REFERENCES jobs(id),
  custom_fields TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS quotations (
  id INTEGER PRIMARY KEY, quote_number TEXT NOT NULL UNIQUE, customer_id INTEGER NOT NULL REFERENCES customers(id),
  treatment TEXT NOT NULL, description TEXT, duration_days INTEGER NOT NULL CHECK(duration_days > 0),
  treatment_start TEXT, subtotal REAL NOT NULL, tax_rate REAL NOT NULL DEFAULT 0, discount REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL, cost_estimate REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Draft',
  payment_status TEXT NOT NULL DEFAULT 'Unpaid', line_items TEXT NOT NULL DEFAULT '[]', created_by INTEGER NOT NULL REFERENCES users(id),
  approved_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY, invoice_number TEXT NOT NULL UNIQUE, quotation_id INTEGER REFERENCES quotations(id),
  job_id INTEGER REFERENCES jobs(id), customer_id INTEGER NOT NULL REFERENCES customers(id), amount REAL NOT NULL, tax REAL NOT NULL DEFAULT 0,
  discount REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Issued', payment_status TEXT NOT NULL DEFAULT 'Unpaid',
  due_date TEXT, paid_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY, job_number TEXT NOT NULL UNIQUE, quotation_id INTEGER NOT NULL UNIQUE REFERENCES quotations(id),
  customer_id INTEGER NOT NULL REFERENCES customers(id), operator_id INTEGER REFERENCES operators(id),
  treatment TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Scheduled', start_at TEXT NOT NULL, end_at TEXT NOT NULL,
  service_location_id INTEGER REFERENCES locations(id), priority TEXT NOT NULL DEFAULT 'Normal', revenue REAL NOT NULL DEFAULT 0,
  estimated_cost REAL NOT NULL DEFAULT 0, actual_cost REAL NOT NULL DEFAULT 0, completed_at TEXT, cancelled_at TEXT,
  override_reason TEXT, custom_fields TEXT NOT NULL DEFAULT '{}', created_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS allocations (
  id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL REFERENCES jobs(id), resource_type TEXT NOT NULL,
  resource_id INTEGER NOT NULL, quantity REAL NOT NULL DEFAULT 1, allocated_from TEXT NOT NULL, allocated_until TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Allocated', override_reason TEXT, created_by INTEGER NOT NULL REFERENCES users(id),
  returned_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_active_allocation ON allocations(job_id, resource_type, resource_id) WHERE status NOT IN ('Returned','Cancelled','Consumed');
CREATE TABLE IF NOT EXISTS schedules (
  id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL REFERENCES jobs(id), operator_id INTEGER REFERENCES operators(id),
  starts_at TEXT NOT NULL, ends_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Scheduled', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS shipments (
  id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL REFERENCES jobs(id), tracking_number TEXT, carrier TEXT,
  from_location_id INTEGER REFERENCES locations(id), to_location_id INTEGER REFERENCES locations(id), status TEXT NOT NULL,
  shipped_at TEXT, received_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS collections (
  id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL REFERENCES jobs(id), assigned_operator_id INTEGER REFERENCES operators(id),
  location_id INTEGER REFERENCES locations(id), scheduled_at TEXT NOT NULL, collected_at TEXT, status TEXT NOT NULL DEFAULT 'Pending',
  notes TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS maintenance (
  id INTEGER PRIMARY KEY, device_id INTEGER NOT NULL REFERENCES devices(id), kind TEXT NOT NULL, status TEXT NOT NULL,
  scheduled_at TEXT, started_at TEXT, completed_at TEXT, cost REAL NOT NULL DEFAULT 0, notes TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS proofs (
  id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL REFERENCES jobs(id), collection_id INTEGER REFERENCES collections(id),
  operator_id INTEGER NOT NULL REFERENCES operators(id), kind TEXT NOT NULL, file_path TEXT NOT NULL,
  original_name TEXT NOT NULL, mime_type TEXT NOT NULL, file_sha256 TEXT NOT NULL, captured_at TEXT NOT NULL,
  latitude REAL, longitude REAL, metadata TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), kind TEXT NOT NULL, title TEXT NOT NULL,
  message TEXT NOT NULL, job_id INTEGER REFERENCES jobs(id), read_at TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attachments (
  id INTEGER PRIMARY KEY, entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL, file_path TEXT NOT NULL,
  original_name TEXT NOT NULL, mime_type TEXT NOT NULL, file_sha256 TEXT NOT NULL,
  uploaded_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS custom_field_definitions (
  id INTEGER PRIMARY KEY, entity_type TEXT NOT NULL, field_key TEXT NOT NULL, label TEXT NOT NULL,
  field_type TEXT NOT NULL, required INTEGER NOT NULL DEFAULT 0, options TEXT NOT NULL DEFAULT '[]', active INTEGER NOT NULL DEFAULT 1,
  UNIQUE(entity_type, field_key)
);
CREATE TABLE IF NOT EXISTS status_definitions (
  id INTEGER PRIMARY KEY, entity_type TEXT NOT NULL, name TEXT NOT NULL, color TEXT NOT NULL DEFAULT '#64748b',
  terminal INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 0,
  UNIQUE(entity_type, name)
);
CREATE TABLE IF NOT EXISTS inventory_history (
  id INTEGER PRIMARY KEY, resource_type TEXT NOT NULL, resource_id INTEGER NOT NULL, job_id INTEGER REFERENCES jobs(id),
  from_status TEXT, to_status TEXT NOT NULL, from_location_id INTEGER REFERENCES locations(id), to_location_id INTEGER REFERENCES locations(id),
  operator_id INTEGER REFERENCES operators(id), notes TEXT, changed_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY, actor_user_id INTEGER REFERENCES users(id), action TEXT NOT NULL, entity_type TEXT NOT NULL,
  entity_id TEXT, before_data TEXT, after_data TEXT, ip_address TEXT, user_agent TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS import_batches (
  id INTEGER PRIMARY KEY, entity_type TEXT NOT NULL, filename TEXT NOT NULL, status TEXT NOT NULL,
  rows_total INTEGER NOT NULL DEFAULT 0, rows_imported INTEGER NOT NULL DEFAULT 0, rows_failed INTEGER NOT NULL DEFAULT 0,
  error_report TEXT NOT NULL DEFAULT '[]', uploaded_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL, completed_at TEXT
);

CREATE INDEX IF NOT EXISTS ix_jobs_dates ON jobs(start_at, end_at);
CREATE INDEX IF NOT EXISTS ix_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS ix_alloc_resource ON allocations(resource_type, resource_id, allocated_from, allocated_until);
CREATE INDEX IF NOT EXISTS ix_history_resource ON inventory_history(resource_type, resource_id, created_at);
CREATE INDEX IF NOT EXISTS ix_audit_created ON audit_logs(created_at);
