# API reference

Base path: `/api/v1`. JSON is used for requests/responses. Dates are ISO-8601 UTC. Browser mutation requests send `X-CSRF-Token`; mobile clients send `Authorization: Bearer <api_token>`.

Errors are stable JSON:

```json
{"error":{"code":"allocation_conflict","message":"Resource conflicts with JOB-…","details":null}}
```

## Identity and dashboards

| Method | Path | Role | Description |
|---|---|---|---|
| POST | `/auth/login` | Public | Username/password; returns user, CSRF and API token |
| POST | `/auth/logout` | Signed in | Clear browser session |
| GET | `/me` | Signed in | Current identity/role |
| GET | `/dashboard` | Signed in | Role-specific live dashboard |
| GET | `/analytics` | Admin | Filtered BI: `date_from`, `date_to`, `status`, `operator`, `customer`, `treatment`, `location` |

## Resources

`GET /operators|devices|consumables|customers|quotations|invoices|jobs|collections|notifications|maintenance|audit` lists records. Operator responses are automatically scoped. Admin creation endpoints are:

- `POST /operators`, `/devices`, `/consumables`, `/customers`, `/quotations`
- `PATCH /operators/{id}`, `/devices/{id}`, `/consumables/{id}`, `/customers/{id}`, `/quotations/{id}`, `/invoices/{id}`
- `GET /devices/{id}/history` and `/consumables/{id}/history`
- `POST /devices/{id}/maintenance`

Device example:

```json
{"serial_number":"LMF-X-100","model":"CryoPulse X2","category":"Cryotherapy","status":"Available","location":{"name":"Central","district":"Ernakulam","state":"Kerala","country":"India"}}
```

Quotation pricing is `total = max(0, subtotal - discount) + tax`, with tax applied after discount. Approved quotations are immutable.

## Workflow

| Method | Path | Description |
|---|---|---|
| POST | `/quotations/{id}/approve` | Approve Draft/Sent quote |
| POST | `/quotations/{id}/convert` | Create job, duration schedule and invoice |
| GET | `/recommendations?start_at=&end_at=&location_id=&category=` | Ranked operators/devices plus future availability |
| GET | `/jobs/{id}` | Job with allocations, shipments, collections and proofs |
| POST | `/jobs/{id}/allocations` | Allocate device/consumable for job window |
| POST | `/jobs/{id}/transition` | Apply legal state transition and custody effects |
| POST | `/jobs/{id}/proofs` | Store base64 proof with timestamp and GPS |
| GET | `/proofs/{id}/download` | Authorized proof download |

Job states: `Scheduled → Allocated → Shipped → Received → In Treatment → Awaiting Collection → Collected → Completed`. Supported shortcuts are `Allocated → In Treatment`; cancellation is permitted before collection. Request fields such as `tracking_number`, `carrier`, `scheduled_at`, `actual_cost` and `consume` are accepted when relevant.

Allocation request:

```json
{"resource_type":"device","resource_id":12,"quantity":1,"override_reason":null}
```

Proof request:

```json
{"kind":"Collection","filename":"collection.jpg","content_base64":"/9j/…","captured_at":"2026-08-27T09:30:00Z","latitude":9.9816,"longitude":76.2999,"collection_id":4}
```

## Files, imports and configuration

- `POST/GET /attachments` uploads/lists hashed quotation, invoice, job, inventory or customer documents. `GET /attachments/{id}/download` retrieves them.
- `POST /imports` accepts `{entity_type, filename, content_base64}` for UTF-8 CSV or first-sheet XLSX. Response contains imported/failed counts and row errors.
- `GET/POST /settings/statuses` and `/settings/custom-fields` manage extensibility definitions.
- `POST /notifications/{id}/read` marks the signed-in user's notification read.

## Compatibility

Breaking changes go into `/api/v2`; additive fields may be introduced in v1. Clients should ignore unknown JSON keys and use the stable error `code`, not localized message text.
