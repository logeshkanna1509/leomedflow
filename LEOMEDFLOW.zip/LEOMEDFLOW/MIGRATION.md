# Migrations and historical data

## Move LEOMEDFLOW to another server

For a live installed server, prepare a consistent transfer snapshot while the script briefly stops writes:

```bash
sudo /opt/leomedflow/migrate.sh --prepare-transfer
```

This uses SQLite's backup API, checks database integrity and foreign keys, copies uploads, carries forward the production secret/configuration, then restarts the source service if it was running. Securely copy the entire `/opt/leomedflow` directory to the destination. The generated `transfer/` directory is sensitive and intentionally ignored by version control.

On the destination server:

```bash
cd /path/to/copied/LEOMEDFLOW
sudo ./migrate.sh
systemctl start leomedflow
leomedflow-health
```

The destination installer will not replace an existing `/var/lib/leomedflow/leomedflow.db` or `/etc/leomedflow.env`. It creates a timestamped database backup before applying schema changes. If installation fails, it exits non-zero with a specific error and does not report success.

## Schema migrations

Apply all forward migrations:

```bash
./scripts/migrate.sh
```

This lower-level script only applies database schema migrations for the current environment. Use the top-level `./migrate.sh` for a server installation or transfer.

Applied versions are recorded in `schema_migrations`; reruns are idempotent. The current migration has a complete development rollback:

```bash
./scripts/rollback.sh
```

Rollback drops all application tables and is destructive. Back up first and do not run it against production merely to deploy an older build. Future migrations should be numbered (`002_name.sql`) and include a matching `.down.sql` only when data-safe reversal is possible.

## Interactive CSV/XLSX import

Admin → Historical Import accepts devices, consumables and customers. CSV must be UTF-8. XLSX reads the first worksheet, resolves shared/inline strings and expects row 1 headers. Each batch stores total/imported/failed counts and detailed row errors. Successful rows commit even when other rows fail.

Headers:

- Devices: `serial_number,model,category,status,purchase_cost,maintenance_due_at`
- Consumables: `serial_number,sku,name,batch_number,quantity,unit,unit_cost,status,expiry_date`
- Customers: `code,name,email,phone`

The import uses normal creation services, so unique serials/codes, valid states, quantities and audit/history records are enforced. Empty serial numbers are permitted only for non-serialized consumables.

## Offline/import automation

```bash
python3 scripts/import_history.py devices historical_devices.xlsx --actor 1
python3 scripts/import_history.py consumables historical_stock.csv --actor 1
```

Exit status is non-zero when any row fails. This makes the utility suitable for controlled migration pipelines.

## Historical jobs/documents

The guarded bulk importer deliberately covers low-risk master data. Historical quotations/jobs/allocations are relational and should be migrated with a reviewed, numbered SQL/Python migration that resolves customers, users, locations and serials before inserting workflow facts. Use `POST /api/v1/attachments` for quotation/invoice/job documents or create an organization-specific migration using the same SHA-256/relative-path pattern.

Recommended sequence: locations → users/operators → customers → devices/consumables → quotations → invoices/jobs/schedules → allocations/history → logistics → proofs/attachments → validation totals.

## Validation checklist

- Compare source/target counts and totals by month.
- Confirm all serial uniqueness failures are true duplicates.
- Verify every active allocation points to an active job and usable resource.
- Recalculate job end dates from quote duration.
- Compare invoice/revenue/cost totals and payment state.
- Sample attachment/proof hashes and timestamps.
- Run `python3 -m unittest discover -v` after migration.
