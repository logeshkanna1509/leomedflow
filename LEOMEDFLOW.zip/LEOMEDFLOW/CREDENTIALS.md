# Demo credentials

| Portal | Username | Password | Role |
|---|---|---|---|
| Admin | `admin` | `Admin@12345` | Full administration and analytics |
| Operator | `operator` | `Operator@12345` | Assigned jobs/inventory/collections only |
| Additional seeded operator | `operator2` | `Operator2@12345` | Assigned jobs/inventory/collections only |

These credentials contain no production secrets. Run `python3 manage.py seed` to create them in a new database. Production credentials must be provisioned separately and these accounts disabled or have passwords rotated before real data is loaded.

API login is `POST /api/v1/auth/login`. The response includes a short browser session plus a bearer token for API/mobile testing.
