# Architecture

## Shape

LEOMEDFLOW is a dependency-light three-layer application:

```text
Admin browser ─┐
Operator web ──┼─ HTTPS/reverse proxy ─ versioned REST router ─ business services ─ SQLite
Future apps ───┘                              │                    │
                                             ├─ security/RBAC     ├─ scheduling/allocation
                                             ├─ validation        ├─ workflow/history
                                             └─ uploads           └─ analytics/notifications
```

- `app/server.py` is the transport layer. It parses requests, authenticates sessions/bearer tokens, enforces roles/CSRF, saves files and maps `/api/v1` endpoints.
- `app/services.py` contains business rules independent of the HTML portal: pricing, quote conversion, recommendations, schedule conflict checks, allocation conflict checks, transitions, inventory reconciliation, imports and analytics.
- `app/db.py` owns connections, migrations, transactions, serialization and append-only audit writes.
- `app/security.py` owns password derivation, constant-time verification, signed sessions, bearer tokens and filename normalization.
- `templates/index.html` and `assets/` are a responsive API client. Admin and Operator navigation is role-specific, while server authorization remains authoritative.

## Workflow invariants

1. An approved quotation converts once into a job, schedule and invoice.
2. `job.end_at = job.start_at + quotation.duration_days`; allocations share this exact window.
3. Schedule/resource overlaps use half-open intervals (`existing.start < new.end` and `existing.end > new.start`).
4. Broken, maintenance, lost and retired devices cannot be allocated without an audited Admin override. Consumed, damaged, expired and lost consumables are treated equivalently.
5. Operators can only see and mutate assigned jobs, inventory, collections, proofs and notifications.
6. State transitions are explicit. Arbitrary jumps are rejected.
7. Current inventory columns are a fast projection; `allocations` and `inventory_history` remain historical facts and are never overwritten.
8. Proof file SHA-256 and capture metadata are immutable database records.

## Mobile readiness

Mobile clients authenticate through the same `/api/v1/auth/login` endpoint and use `Authorization: Bearer lmf_…`. Browser-only CSRF is not required for bearer authentication. API responses are JSON, dates are ISO-8601 UTC, errors have stable codes, and no business rules live only in frontend JavaScript.

## Scaling path

SQLite WAL supports the present single-node operational deployment. To scale horizontally, retain the API/service boundary, migrate SQL to PostgreSQL, put uploads in versioned object storage, issue shorter OAuth/OIDC access tokens and move notifications to a durable queue. GPS columns already exist; a future app can provide higher-confidence background/device location capture.

## Security model

Passwords use PBKDF2-HMAC-SHA256 with random salts and 310,000 iterations. Browser sessions are HMAC-signed, HttpOnly and SameSite=Strict; production sets `Secure`. Mutations require CSRF. API tokens are random and only their SHA-256 hashes are stored. Login is rate limited per process/IP. Upload extensions, size, safe names and proof magic bytes are checked. CSP, frame denial, MIME sniffing prevention and no-store API caching are applied.
