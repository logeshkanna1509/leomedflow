# Deployment

## Production prerequisites

- Linux with systemd and Python 3.11+
- TLS reverse proxy (Nginx example below)
- Persistent database/upload directories on encrypted storage
- Backup, monitoring and log rotation

## Portable installation

```bash
sudo ./migrate.sh
systemctl start leomedflow
leomedflow-health
```

The migration installer is idempotent. It validates Python, creates the `leomedflow` system user, installs code read-only in `/opt/leomedflow`, keeps state in `/var/lib/leomedflow`, generates a high-entropy production configuration when needed, imports a bundled or prepared database with SQLite's online backup API, copies missing uploads, validates integrity and foreign keys, takes a pre-migration backup, applies migrations, installs the unit and health command, reloads systemd, and enables boot startup. Existing target data and configuration are never overwritten by a copied source folder.

The service deliberately remains stopped after installation. This makes the post-transfer startup contract exactly `systemctl start leomedflow` followed by `leomedflow-health`.

## systemd

The installer performs the systemd setup. Normal operations are:

```bash
sudo systemctl start leomedflow
leomedflow-health
sudo systemctl status leomedflow
```

The unit applies pending schema migrations in `ExecStartPre`, so ordinary startup remains sufficient after a code transfer. The health command waits up to 30 seconds and requires an active systemd unit, a working database, and writable upload storage.

## Nginx TLS proxy

Use `deployment/nginx.conf` as the site template, replace the hostname/certificate paths, and enable it. The reverse proxy terminates TLS, supplies request limits and forwards the client address. Do not expose port 8080 publicly.

## Environment

| Variable | Required/default | Purpose |
|---|---|---|
| `LEOMEDFLOW_SECRET_KEY` | Required in production | Session HMAC key |
| `LEOMEDFLOW_ENV` | `development`; set `production` | Enforces non-default secret |
| `LEOMEDFLOW_DATABASE` | `instance/leomedflow.db` | SQLite file |
| `LEOMEDFLOW_UPLOAD_DIR` | `uploads/` | Proof/document storage |
| `LEOMEDFLOW_HOST` | `127.0.0.1` | Bind address |
| `LEOMEDFLOW_PORT` | `8080` | Bind port |
| `LEOMEDFLOW_SESSION_HOURS` | `12` | Browser session lifetime |
| `LEOMEDFLOW_MAX_UPLOAD_BYTES` | `10485760` | Request file limit |
| `LEOMEDFLOW_COOKIE_SECURE` | `0`; set `1` | HTTPS-only cookie |

## Release procedure

1. Back up database and uploads; record their hashes.
2. Deploy code to a versioned directory, run tests against a restored backup, then run migrations.
3. Restart service and verify `/health`, Admin login, Operator login, one read query and audit logging.
4. Confirm Nginx security/TLS and upload limits. Monitor logs and SQLite disk space.
5. Roll back code only when schema remains compatible. Use SQL rollback only for a tested, explicitly reversible migration.

## Limits and scale

The bundled threaded server is appropriate for a controlled single-node deployment behind a reverse proxy and supervisor. For higher concurrency/HA, adapt the transport to ASGI/WSGI, migrate SQLite to PostgreSQL, move files to object storage, use a shared rate limiter and integrate OIDC. Email/SMS/push delivery and background GPS require external services; notifications are currently durable in-app records.
