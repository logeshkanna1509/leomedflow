# Handover

## Completed

LEOMEDFLOW 1.0 implements the requested connected commercial-to-treatment workflow with a real relational database and versioned APIs. Admin and Operator portals are responsive and role-scoped. Core modules include dashboards, operators, customers/locations, device/consumable inventory, quotations/invoices, job sheets, recommendations, schedules/allocations, shipments/collections, maintenance, field proofs, notifications, historical import, custom definitions, audit/history and BI.

The seeded data contains completed, active, scheduled, cancelled and maintenance scenarios, two field operators, three customers/locations, six devices, four stock items, invoices, allocations and collection history. The automated test suite exercises authentication, CSRF, RBAC/scoping, CRUD/unique serials, quote duration, schedule conflict/override, allocation conflict/maintenance blocks, all workflow transitions, proof/GPS capture, inventory reconciliation, import duplicate reporting and BI calculations.

## Run and verify

```bash
export LEOMEDFLOW_SECRET_KEY="local-development-secret-change-this"
./scripts/run.sh
# in a second terminal
python3 -m unittest discover -v
```

Open `http://127.0.0.1:8080` and use credentials in `CREDENTIALS.md`.

## Important implementation files

- `app/services.py`: authoritative workflow, scheduling/allocation, history, import and BI rules
- `app/server.py`: v1 API, auth/RBAC/CSRF, uploads and static portal delivery
- `migrations/001_initial.sql`: full relational schema/indexes
- `assets/app.js`: live Admin/Operator portal client and charts
- `tests/test_system.py`: system-level acceptance suite
- `app/seed.py`: idempotent realistic demonstration dataset

## Known limitations / external work

- In-app notifications are durable, but SMS/email/push need provider credentials and a background delivery worker.
- Browser GPS is optional and depends on HTTPS/user permission; a future native app can provide stronger/background GPS evidence.
- Uploaded files use local durable storage. Multi-node deployment requires object storage, malware scanning and organization-specific retention policies.
- The first-sheet XLSX reader covers normal cell/string workbooks, not macros, formulas requiring recalculation, password protection or complex merged layouts.
- SQLite and the bundled threaded transport target a supervised, reverse-proxied single node. Horizontal scale calls for PostgreSQL, a production ASGI/WSGI transport, shared token/rate-limit infrastructure and object storage.
- There are no external tax, accounting, carrier-tracking, maps/geocoding, payment, SMS or push integrations; their boundaries are represented but credentials/contracts were not provided.
- Custom status/field definitions are manageable and stored; core state-machine statuses remain intentionally fixed to protect accounting/inventory invariants. New core transitions require a reviewed migration/service change.

## Recommended continuation

1. Confirm organization-specific treatment fields, invoice numbering/tax rules, proof retention and role matrix.
2. Add password-reset/admin credential rotation UI and optional OIDC/MFA.
3. Integrate selected messaging, carrier, accounting and object-storage providers.
4. Build mobile apps against `/api/v1`, using bearer tokens and native camera/GPS.
5. Before wider production use, migrate money fields to decimal PostgreSQL columns, add concurrency/load tests, malware scanning, off-site backups and security review.
