# LEOMEDFLOW

LEOMEDFLOW is a connected inventory and treatment-operations application covering quotation → job → assignment → inventory allocation → shipping → treatment → collection → completion → inventory reconciliation → business intelligence.

It provides a secure Admin Portal, a scoped Operator Portal, and versioned REST APIs designed for reuse by future Android/iOS apps. All dashboard values and screens use SQLite data; there are no mock API responses or static workflow screens.

## Quick start

Requirements: Python 3.11 or newer. There are no third-party runtime packages.

```bash
cd LEOMEDFLOW
export LEOMEDFLOW_SECRET_KEY="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
./scripts/run.sh
```

Open <http://127.0.0.1:8080>. The run script applies migrations and safely seeds demo data once.

For separate steps:

```bash
python3 manage.py migrate
python3 manage.py seed
python3 manage.py run --host 127.0.0.1 --port 8080
python3 -m unittest discover -v
```

## One-command server migration

On a new Linux server with Python 3.11+ and systemd, copy this entire folder and run:

```bash
sudo ./migrate.sh
systemctl start leomedflow
leomedflow-health
```

`migrate.sh` installs the application under `/opt/leomedflow`, preserves/imports the database and uploads, creates an unprivileged service account and production secret, applies schema migrations, installs/enables the systemd unit, and installs `leomedflow-health`. It does not start the service, so the final two commands are always the same.

When moving an already-installed, live server, first create a consistent portable snapshot on the old server:

```bash
sudo /opt/leomedflow/migrate.sh --prepare-transfer
```

Then securely copy the entire `/opt/leomedflow` folder to the new server. The `transfer/` directory contains the live database, uploads, and secret configuration; handle it as sensitive data.

## Demo credentials

- Admin: `admin` / `Admin@12345`
- Operator: `operator` / `Operator@12345`

These are demonstration credentials only. Change or remove them before using real data. Login also returns a 30-day bearer token for mobile/API clients; the browser uses an HttpOnly, SameSite session and CSRF protection.

## Functional coverage

- Role-scoped authentication, PBKDF2-SHA256 password hashes, rate-limited login, bearer tokens, CSRF, security headers, protected routes, audit logging, and configurable environment secrets.
- Operators, customers, district/state/country locations, unique devices, serialized/batched consumables, quotations, auto-created invoices, jobs, schedules, allocations, shipments, collections, maintenance, notifications, uploads and proof records.
- Treatment duration automatically determines `end_at` and all allocation windows. Operator overlap and resource overlap are blocked. Recommendations rank conflict-free operators/devices using availability, workload, location proximity, status and maintenance state; future availability dates are returned.
- Explicit job state machine with custody updates. Completion returns devices, consumes or returns consumables, closes schedules and preserves every allocation/status history row.
- Operator field proof captures file hash, original name, timestamp, signed-in identity, job, allocated serial numbers and optional browser GPS coordinates.
- Filtered BI includes revenue, cost, gross profit/margin, job mix, customer/treatment/operator/location profitability, device utilization/downtime/revenue, consumable cost and collection turnaround.
- CSV/XLSX imports validate rows, reject duplicates and retain a permanent batch/error report.
- Configurable status catalog and custom field definitions.

## Project layout

```text
app/            database, security, business services, HTTP/API server, seed
assets/         responsive portal CSS and JavaScript
templates/      shared Admin/Operator application shell
migrations/     forward and rollback SQL
scripts/        run, migrate, rollback, seed and historical import utilities
tests/          automated API and end-to-end workflow tests
uploads/        proof/attachment files (not committed)
instance/       SQLite database (not committed)
deployment/     systemd and Nginx examples
```

See [ARCHITECTURE.md](ARCHITECTURE.md), [API.md](API.md), [DATABASE.md](DATABASE.md), and [DEPLOYMENT.md](DEPLOYMENT.md) for implementation and production operations.
