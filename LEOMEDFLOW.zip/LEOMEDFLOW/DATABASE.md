# Database

SQLite is configured with foreign keys, WAL journaling and a busy timeout. Timestamps are stored as ISO-8601 UTC text. Money is stored as decimal-like two-place `REAL` values in this release; a PostgreSQL migration should use `NUMERIC(14,2)`.

## Entity groups

| Group | Tables | Purpose |
|---|---|---|
| Identity | `roles`, `users`, `api_tokens`, `operators` | RBAC, credentials, operator capacity/skills |
| Geography/CRM | `locations`, `customers` | Manual address/district/state/country and optional GPS |
| Inventory | `devices`, `consumables`, `maintenance`, `inventory_history` | Current projection plus immutable custody/status events |
| Commercial | `quotations`, `invoices` | Pricing, duration, approval and payment state |
| Operations | `jobs`, `schedules`, `allocations`, `shipments`, `collections` | Treatment schedule and full resource/logistics workflow |
| Evidence | `proofs`, `attachments` | Hashed proof and business documents |
| Communication | `notifications` | Assignment/treatment/collection prompts |
| Extensibility | `custom_field_definitions`, `status_definitions` | Business-defined fields and display statuses |
| Governance/import | `audit_logs`, `import_batches`, `schema_migrations` | Change trail, row error reports and migration state |

## Important constraints and indexes

- Unique: usernames, employee codes, device serial numbers, non-null consumable serial numbers, customer codes, quote/invoice/job numbers and one job per quotation.
- Active duplicate allocation within the same job/resource is prevented by `uq_active_allocation`; cross-job time conflicts are enforced transactionally by the allocation service.
- `ix_jobs_dates`, `ix_jobs_status`, `ix_alloc_resource`, `ix_history_resource` and `ix_audit_created` support core operational queries.
- Foreign keys prevent detached identities, jobs and documents. Generic history/custom-field targets intentionally use `(entity_type, entity_id)` so the schema remains extensible.

## Current versus history

`devices.status/current_job_id/current_operator_id` and equivalent consumable columns answer current-state queries efficiently. Every custody change also appends to `inventory_history`, and every assignment remains in `allocations`. Completing or editing a job never deletes these records.

## Backups

Use SQLite's online backup command through Python rather than copying a live database file:

```bash
python3 - <<'PY'
import sqlite3
source=sqlite3.connect('instance/leomedflow.db')
target=sqlite3.connect('leomedflow-backup.db')
source.backup(target)
target.close(); source.close()
PY
```

Back up `uploads/` with the database. Restore and verify both together because proof rows reference stored relative paths and hashes.
