# Operational procedures

## Daily Admin workflow

1. Review Command Center alerts, upcoming treatments, device exceptions, low stock and pending collections.
2. Create or update customer/location records. Create a quotation with treatment, duration, expected start, pricing, discount, tax, line items and cost estimate; attach the signed commercial document if needed.
3. Approve the quotation. Approval locks commercial editing. Choose **Create job**, inspect operator/device recommendations and select the operator. Use an override reason only when a supervisor has accepted a real conflict/exception.
4. Open the job and allocate devices/consumables. LEOMEDFLOW rejects time overlaps and unusable stock. Confirm serial numbers and quantity before proceeding.
5. Progress the shipment and treatment states. Shipment creates a logistics record; receipt moves custody/location; treatment changes allocated inventory to In Use.
6. At treatment end, move to Awaiting Collection. The assigned operator receives job, location and serial details.
7. Operator collects, uploads proof with location enabled, then marks Collected. Admin/operator records actual cost and completes the job. Confirm the device is Available and consumable balance is correct.
8. Update invoice payment state and review BI margin/utilization/turnaround.

## Operator procedure

1. Sign into the Operator Portal and review My Day and notifications.
2. Open an assigned job. Verify customer, service location, treatment window and every device/consumable serial before accepting custody.
3. Update only when the physical event occurs: Received, In Treatment, Awaiting Collection or Collected. Never pre-record a step.
4. For proof, allow browser location access, choose a photo/PDF, and upload. The system records time, account, job and serial list automatically. If GPS is unavailable, complete the upload and document the reason operationally.
5. After physical return/collection, mark Collected. Completion reconciles inventory; report damaged, missing or broken assets to an Admin before completion so their state can be recorded.

## Exceptions

- **Broken/maintenance device:** do not allocate. Admin creates a maintenance record and uses a different recommendation. Only an explicit documented override bypasses the guard.
- **Lost/damaged stock:** update status; preserve evidence/notes. Do not delete or reuse its serial.
- **Schedule conflict:** select another operator/date. Overrides are audited and should name the authorizing manager.
- **Wrong workflow event:** do not create compensating false events. Contact an Admin; inspect audit/history and apply the next truthful state. Database correction should be a controlled migration.
- **Duplicate import row:** download/read the returned row report, correct the source, and import only failed/corrected rows. Successfully imported rows should not be repeated.

## Maintenance and stock

Review maintenance-due alerts daily and the fleet report weekly. A Scheduled/In Progress maintenance record makes the device unavailable. Record completion, cost and notes before returning it to Available. Review consumable expiry and low-stock alerts, use FEFO (first-expiring-first-out), and physically quarantine Expired/Damaged items.

## Audit and evidence retention

Audit, allocation, inventory history and proof rows are operational records and must not be deleted. Back up the database and `uploads/` together. Periodically sample downloaded proofs and compare their SHA-256 to the database. Define actual retention periods with the organization's legal/privacy owner.
