#!/usr/bin/env sh
set -eu
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
if [ "${1:-}" = "--prepare-transfer" ]; then
    shift
    exec "$PROJECT_DIR/scripts/prepare-transfer.sh" "$@"
fi
exec "$PROJECT_DIR/scripts/install-server.sh" "$@"
