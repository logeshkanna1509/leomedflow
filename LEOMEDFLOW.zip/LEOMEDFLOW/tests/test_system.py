from __future__ import annotations

import base64
import io
import json
import sqlite3
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timedelta, timezone
from http.server import ThreadingHTTPServer
from pathlib import Path

from app import config
from app.db import connect
from app.seed import seed
from app.security import verify_password
from app.server import Handler, RATE_LIMIT


class SystemTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); root=Path(self.tmp.name)
        config.DATABASE=root/"test.db"; config.UPLOAD_DIR=root/"uploads"; config.UPLOAD_DIR.mkdir(); config.SECRET_KEY="test-secret-key-32-bytes-minimum-value"
        RATE_LIMIT.clear(); seed(config.DATABASE)
        self.server=ThreadingHTTPServer(("127.0.0.1",0),Handler); self.thread=threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start()
        self.base=f"http://127.0.0.1:{self.server.server_address[1]}"; self.admin=self.login("admin","Admin@12345"); self.operator=self.login("operator","Operator@12345")

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=2); self.tmp.cleanup()

    def request(self,path,data=None,token=None,headers=None,method=None):
        payload=json.dumps(data).encode() if data is not None else None; hdr={"Content-Type":"application/json",**(headers or {})}
        if token: hdr["Authorization"]="Bearer "+token
        req=urllib.request.Request(self.base+"/api/v1"+path,data=payload,headers=hdr,method=method)
        try:
            response=urllib.request.urlopen(req,timeout=5); return response.status,json.load(response),response.headers
        except urllib.error.HTTPError as exc: return exc.code,json.load(exc),exc.headers

    def login(self,username,password):
        code,body,headers=self.request("/auth/login",{"username":username,"password":password})
        self.assertEqual(code,200); body["cookie"]=headers.get("Set-Cookie").split(";",1)[0]; return body

    def create_quote_job(self,start=None,operator_id=1):
        start=start or (datetime.now(timezone.utc)+timedelta(days=40)).replace(microsecond=0).isoformat()
        code,q,_=self.request("/quotations",{"customer_id":1,"treatment":"Automated test therapy","duration_days":3,"treatment_start":start,"subtotal":10000,"tax_rate":5,"discount":500,"cost_estimate":2500},self.admin["api_token"]); self.assertEqual(code,201,q)
        self.assertEqual(self.request(f"/quotations/{q['id']}/approve",{},self.admin["api_token"])[0],200)
        code,j,_=self.request(f"/quotations/{q['id']}/convert",{"start_at":start,"operator_id":operator_id},self.admin["api_token"]); self.assertEqual(code,201,j)
        return q,j

    def test_authentication_password_hash_and_csrf(self):
        with connect(config.DATABASE) as c: encoded=c.execute("SELECT password_hash FROM users WHERE username='admin'").fetchone()[0]
        self.assertNotIn("Admin@12345",encoded); self.assertTrue(verify_password("Admin@12345",encoded))
        self.assertEqual(self.request("/auth/login",{"username":"admin","password":"wrong-password"})[0],401)
        cookie=self.admin["cookie"]
        code,body,_=self.request("/devices",{"serial_number":"CSRF-1","model":"M","category":"T"},headers={"Cookie":cookie})
        self.assertEqual(code,403); self.assertEqual(body["error"]["code"],"csrf_failed")
        code,_,_=self.request("/devices",{"serial_number":"CSRF-2","model":"M","category":"T"},headers={"Cookie":cookie,"X-CSRF-Token":self.admin["csrf_token"]})
        self.assertEqual(code,201)

    def test_health_checks_database_and_upload_storage(self):
        with urllib.request.urlopen(self.base+"/health",timeout=5) as response:
            body=json.load(response)
        self.assertEqual(response.status,200)
        self.assertEqual(body["status"],"ok")
        self.assertEqual(body["checks"],{"database":"ok","uploads":"ok"})
        self.assertEqual(body["migration"],"001_initial")

    def test_role_permissions_and_operator_scoping(self):
        code,body,_=self.request("/analytics",token=self.operator["api_token"]); self.assertEqual(code,403); self.assertEqual(body["error"]["code"],"forbidden")
        code,body,_=self.request("/jobs",token=self.operator["api_token"]); self.assertEqual(code,200)
        self.assertTrue(body["items"]); self.assertTrue(all(x["operator_id"]==1 for x in body["items"]))
        self.assertEqual(self.request("/customers",token=self.operator["api_token"])[0],403)
        self.assertEqual(self.request("/operators/1/password",{"password":"NewOperator@123"},self.admin["api_token"])[0],200)
        self.assertEqual(self.request("/jobs",token=self.operator["api_token"])[0],401)
        self.assertEqual(self.request("/auth/login",{"username":"operator","password":"NewOperator@123"})[0],200)

    def test_crud_and_serial_uniqueness(self):
        item={"serial_number":"UNIQUE-9001","model":"Pulse Q","category":"Cryotherapy","location":{"district":"Kochi","state":"Kerala","country":"India"}}
        self.assertEqual(self.request("/devices",item,self.admin["api_token"])[0],201)
        code,body,_=self.request("/devices",item,self.admin["api_token"]); self.assertEqual(code,409); self.assertEqual(body["error"]["code"],"duplicate_serial")
        code,body,_=self.request("/devices/7",{"status":"Broken","maintenance_due_at":"2026-09-01"},self.admin["api_token"],method="PATCH"); self.assertEqual(code,200); self.assertEqual(body["status"],"Broken")
        code,history,_=self.request("/devices/7/history",token=self.admin["api_token"]); self.assertEqual(code,200); self.assertEqual(history["items"][0]["to_status"],"Broken")
        self.assertEqual(self.request("/customers",{"code":"NEW-1","name":"New Clinical Centre","location":{"district":"Kollam","state":"Kerala","country":"India"}},self.admin["api_token"])[0],201)

    def test_duration_calculation_and_operator_conflict(self):
        start=(datetime.now(timezone.utc)+timedelta(days=90)).replace(microsecond=0).isoformat(); _,job=self.create_quote_job(start)
        self.assertEqual(datetime.fromisoformat(job["end_at"])-datetime.fromisoformat(job["start_at"]),timedelta(days=3))
        code,q,_=self.request("/quotations",{"customer_id":2,"treatment":"Overlap","duration_days":2,"subtotal":5000},self.admin["api_token"]); self.assertEqual(code,201)
        self.request(f"/quotations/{q['id']}/approve",{},self.admin["api_token"])
        code,body,_=self.request(f"/quotations/{q['id']}/convert",{"start_at":start,"operator_id":1},self.admin["api_token"]); self.assertEqual(code,409); self.assertEqual(body["error"]["code"],"scheduling_conflict")
        code,_,_=self.request(f"/quotations/{q['id']}/convert",{"start_at":start,"operator_id":1,"override_reason":"Clinical director approved additional crew"},self.admin["api_token"]); self.assertEqual(code,201)

    def test_allocation_conflict_and_maintenance_block(self):
        _,job=self.create_quote_job(); code,body,_=self.request(f"/jobs/{job['id']}/allocations",{"resource_type":"device","resource_id":4},self.admin["api_token"])
        self.assertEqual(code,409); self.assertEqual(body["error"]["code"],"unavailable")
        code,dev,_=self.request("/devices",{"serial_number":"ALLOC-1","model":"T","category":"Test"},self.admin["api_token"]); self.assertEqual(code,201)
        self.assertEqual(self.request(f"/jobs/{job['id']}/allocations",{"resource_type":"device","resource_id":dev["id"]},self.admin["api_token"])[0],201)
        later_start=(datetime.now(timezone.utc)+timedelta(days=41)).replace(microsecond=0).isoformat(); _,job2=self.create_quote_job(later_start,operator_id=2)
        code,body,_=self.request(f"/jobs/{job2['id']}/allocations",{"resource_type":"device","resource_id":dev["id"]},self.admin["api_token"]); self.assertEqual(code,409); self.assertEqual(body["error"]["code"],"allocation_conflict")

    def test_full_workflow_proof_gps_and_inventory_reconciliation(self):
        _,job=self.create_quote_job(operator_id=1)
        _,dev,_=self.request("/devices",{"serial_number":"FLOW-D-1","model":"Flow","category":"Test"},self.admin["api_token"])
        _,con,_=self.request("/consumables",{"serial_number":"FLOW-C-1","sku":"FLOW-C","name":"Flow consumable","quantity":5,"unit_cost":10},self.admin["api_token"])
        self.assertEqual(self.request(f"/jobs/{job['id']}/allocations",{"resource_type":"device","resource_id":dev["id"]},self.admin["api_token"])[0],201)
        self.assertEqual(self.request(f"/jobs/{job['id']}/allocations",{"resource_type":"consumable","resource_id":con["id"],"quantity":2},self.admin["api_token"])[0],201)
        for step in ["Shipped","Received","In Treatment","Awaiting Collection"]:
            code,_,_=self.request(f"/jobs/{job['id']}/transition",{"status":step},self.operator["api_token"]); self.assertEqual(code,200,step)
        png=base64.b64encode(b"\x89PNG\r\n\x1a\n"+b"proof-data").decode()
        proof={"filename":"collection.png","content_base64":png,"kind":"Collection","captured_at":datetime.now(timezone.utc).isoformat(),"latitude":9.98,"longitude":76.28}
        code,body,_=self.request(f"/jobs/{job['id']}/proofs",proof,self.operator["api_token"]); self.assertEqual(code,201,body); self.assertIn("FLOW-D-1",body["serial_numbers"])
        self.assertEqual(self.request(f"/jobs/{job['id']}/transition",{"status":"Collected"},self.operator["api_token"])[0],200)
        self.assertEqual(self.request(f"/jobs/{job['id']}/transition",{"status":"Completed","actual_cost":2000},self.operator["api_token"])[0],200)
        with connect(config.DATABASE) as c:
            self.assertEqual(tuple(c.execute("SELECT status,current_job_id FROM devices WHERE id=?",(dev["id"],)).fetchone()),("Available",None))
            self.assertEqual(tuple(c.execute("SELECT quantity,status FROM consumables WHERE id=?",(con["id"],)).fetchone()),(3.0,"Available"))
            proofrow=c.execute("SELECT latitude,longitude,file_sha256,metadata FROM proofs WHERE job_id=?",(job["id"],)).fetchone(); self.assertEqual((proofrow[0],proofrow[1]),(9.98,76.28)); self.assertIn("FLOW-C-1",proofrow[3])
            self.assertGreaterEqual(c.execute("SELECT COUNT(*) FROM inventory_history WHERE job_id=?",(job["id"],)).fetchone()[0],8)

    def test_invalid_gps_and_transition_validation(self):
        _,job=self.create_quote_job(); png=base64.b64encode(b"\x89PNG\r\n\x1a\nproof").decode()
        code,body,_=self.request(f"/jobs/{job['id']}/proofs",{"filename":"x.png","content_base64":png,"kind":"Completion","captured_at":datetime.now(timezone.utc).isoformat(),"latitude":100},self.operator["api_token"])
        self.assertEqual(code,400); self.assertIn("latitude",body["error"]["message"])
        code,body,_=self.request(f"/jobs/{job['id']}/transition",{"status":"Completed"},self.admin["api_token"]); self.assertEqual(code,409); self.assertEqual(body["error"]["code"],"invalid_transition")

    def test_csv_import_duplicate_report(self):
        content="serial_number,model,category,status\nIMP-1,Model A,Cryo,Available\nLMF-CRYO-1001,Duplicate,Cryo,Available\n"
        code,body,_=self.request("/imports",{"entity_type":"devices","filename":"history.csv","content_base64":base64.b64encode(content.encode()).decode()},self.admin["api_token"])
        self.assertEqual(code,201); self.assertEqual(body["rows_imported"],1); self.assertEqual(body["rows_failed"],1); self.assertEqual(body["errors"][0]["row"],3)

    def test_xlsx_import_and_document_attachment(self):
        strings=["code","name","email","phone","XLS-1","Workbook Clinic","book@example.test","12345"]
        shared='<?xml version="1.0"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'+''.join(f'<si><t>{x}</t></si>' for x in strings)+'</sst>'
        sheet='<?xml version="1.0"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1">'+''.join(f'<c r="{chr(65+i)}1" t="s"><v>{i}</v></c>' for i in range(4))+'</row><row r="2">'+''.join(f'<c r="{chr(65+i)}2" t="s"><v>{i+4}</v></c>' for i in range(4))+'</row></sheetData></worksheet>'
        mem=io.BytesIO()
        with zipfile.ZipFile(mem,"w") as z: z.writestr("xl/sharedStrings.xml",shared); z.writestr("xl/worksheets/sheet1.xml",sheet)
        code,body,_=self.request("/imports",{"entity_type":"customers","filename":"customers.xlsx","content_base64":base64.b64encode(mem.getvalue()).decode()},self.admin["api_token"])
        self.assertEqual(code,201,body); self.assertEqual(body["rows_imported"],1)
        pdf=base64.b64encode(b"%PDF-1.4\nDemo quotation").decode(); code,attachment,_=self.request("/attachments",{"entity_type":"quotation","entity_id":1,"filename":"signed-quote.pdf","content_base64":pdf},self.admin["api_token"])
        self.assertEqual(code,201,attachment); code,listing,_=self.request("/attachments?entity_type=quotation&entity_id=1",token=self.admin["api_token"]); self.assertEqual(code,200); self.assertEqual(listing["items"][0]["file_sha256"],attachment["sha256"])

    def test_dashboard_and_bi_calculations(self):
        code,d,_=self.request("/dashboard",token=self.admin["api_token"]); self.assertEqual(code,200); self.assertGreater(d["kpis"]["revenue"],0); self.assertEqual(d["kpis"]["completed_jobs"],2)
        code,bi,_=self.request("/analytics",token=self.admin["api_token"]); self.assertEqual(code,200); self.assertAlmostEqual(bi["kpis"]["gross_profit"],bi["kpis"]["revenue"]-bi["kpis"]["cost"]); self.assertTrue(bi["devices"]); self.assertTrue(bi["by_operator"])


if __name__=="__main__": unittest.main()
