#!/usr/bin/env python3
"""Offline CSV/XLSX historical importer with the same validation as the API."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from app.db import migrate, transaction
from app.services import import_csv


def main() -> None:
    p=argparse.ArgumentParser(); p.add_argument("entity",choices=["devices","consumables","customers"]); p.add_argument("file",type=Path); p.add_argument("--actor",type=int,default=1)
    a=p.parse_args(); migrate()
    if a.file.suffix.lower() not in (".csv",".xlsx"): p.error("file must be .csv or .xlsx")
    with transaction() as conn: result=import_csv(conn,a.entity,a.file.name,a.file.read_bytes(),a.actor)
    print(f"{result['status']}: {result['rows_imported']} imported, {result['rows_failed']} failed")
    for err in result["errors"]: print(f"row {err['row']}: {err['error']}")
    raise SystemExit(1 if result["rows_failed"] else 0)


if __name__=="__main__": main()
