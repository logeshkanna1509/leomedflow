#!/usr/bin/env sh
# Make an installed server's live database, uploads, and configuration portable.
set -eu

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
DATA_DIR=/var/lib/leomedflow
ENV_FILE=/etc/leomedflow.env
TRANSFER_DIR=$PROJECT_DIR/transfer
WAS_ACTIVE=0

fail() {
    printf 'LEOMEDFLOW transfer error: %s\n' "$*" >&2
    exit 1
}

restore_service() {
    if [ "$WAS_ACTIVE" -eq 1 ]; then
        systemctl start leomedflow.service
    fi
}

[ "$(id -u)" -eq 0 ] || fail "run this script as root"
[ -s "$DATA_DIR/leomedflow.db" ] || fail "live database not found at $DATA_DIR/leomedflow.db"
[ -f "$ENV_FILE" ] || fail "configuration not found at $ENV_FILE"

if systemctl is-active --quiet leomedflow.service 2>/dev/null; then
    WAS_ACTIVE=1
    systemctl stop leomedflow.service
fi
trap restore_service EXIT HUP INT TERM

install -d -o root -g root -m 0700 "$TRANSFER_DIR"
LEOMEDFLOW_SOURCE_DB=$DATA_DIR/leomedflow.db LEOMEDFLOW_TARGET_DB=$TRANSFER_DIR/leomedflow.db python3 - <<'PY' || fail "database export failed"
import os
import sqlite3
from pathlib import Path

source = Path(os.environ["LEOMEDFLOW_SOURCE_DB"])
target = Path(os.environ["LEOMEDFLOW_TARGET_DB"])
temporary = target.with_suffix(".db.exporting")
with sqlite3.connect(source) as src:
    integrity = src.execute("PRAGMA integrity_check").fetchone()
    foreign_keys = src.execute("PRAGMA foreign_key_check").fetchall()
    if not integrity or integrity[0] != "ok" or foreign_keys:
        raise SystemExit("source database validation failed")
    with sqlite3.connect(temporary) as dst:
        src.backup(dst)
os.replace(temporary, target)
PY

LEOMEDFLOW_SOURCE_UPLOADS=$DATA_DIR/uploads LEOMEDFLOW_TARGET_UPLOADS=$TRANSFER_DIR/uploads python3 - <<'PY' || fail "upload export failed"
import os
import shutil
from pathlib import Path

source = Path(os.environ["LEOMEDFLOW_SOURCE_UPLOADS"])
target = Path(os.environ["LEOMEDFLOW_TARGET_UPLOADS"])
if target.exists():
    shutil.rmtree(target)
if source.exists():
    shutil.copytree(source, target)
else:
    target.mkdir()
PY

install -o root -g root -m 0600 "$ENV_FILE" "$TRANSFER_DIR/leomedflow.env"
find "$TRANSFER_DIR/uploads" -type d -exec chmod 0700 {} \;
find "$TRANSFER_DIR/uploads" -type f -exec chmod 0600 {} \;
chmod 0600 "$TRANSFER_DIR/leomedflow.db"

printf '%s\n' "Transfer snapshot prepared at $TRANSFER_DIR"
printf '%s\n' 'Copy the entire LEOMEDFLOW folder securely to the new server, then run:'
printf '%s\n' '  sudo ./migrate.sh'
printf '%s\n' '  systemctl start leomedflow'
printf '%s\n' '  leomedflow-health'
