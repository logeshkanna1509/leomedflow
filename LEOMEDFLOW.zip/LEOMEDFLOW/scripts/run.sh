#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
python3 manage.py migrate
python3 manage.py seed
exec python3 manage.py run "${@}"
