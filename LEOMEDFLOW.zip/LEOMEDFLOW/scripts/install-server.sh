#!/usr/bin/env sh
# Install or migrate a copied LEOMEDFLOW folder onto a systemd Linux server.
set -eu

SOURCE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
APP_DIR=/opt/leomedflow
DATA_DIR=/var/lib/leomedflow
UPLOAD_DIR=$DATA_DIR/uploads
BACKUP_DIR=$DATA_DIR/backups
ENV_FILE=/etc/leomedflow.env
UNIT_FILE=/etc/systemd/system/leomedflow.service
HEALTH_BIN=/usr/local/bin/leomedflow-health
SERVICE_USER=leomedflow

fail() {
    printf 'LEOMEDFLOW migration error: %s\n' "$*" >&2
    exit 1
}

[ "$(id -u)" -eq 0 ] || fail "run this script as root: sudo ./migrate.sh"

for command_name in python3 systemctl install cp getent; do
    command -v "$command_name" >/dev/null 2>&1 || fail "required command not found: $command_name"
done

python3 - <<'PY' || fail "Python 3.11 or newer is required"
import sys
raise SystemExit(0 if sys.version_info >= (3, 11) else 1)
PY

[ -f "$SOURCE_DIR/manage.py" ] || fail "manage.py is missing from $SOURCE_DIR"
[ -f "$SOURCE_DIR/deployment/leomedflow.service" ] || fail "systemd unit is missing"
[ -x "$SOURCE_DIR/scripts/leomedflow-health" ] || fail "health command is missing or not executable"
[ -x "$SOURCE_DIR/scripts/prepare-transfer.sh" ] || fail "transfer preparation command is missing or not executable"

if ! getent group "$SERVICE_USER" >/dev/null 2>&1; then
    command -v groupadd >/dev/null 2>&1 || fail "groupadd is required to create the service group"
    groupadd --system "$SERVICE_USER"
fi
if ! getent passwd "$SERVICE_USER" >/dev/null 2>&1; then
    command -v useradd >/dev/null 2>&1 || fail "useradd is required to create the service account"
    useradd --system --gid "$SERVICE_USER" --home-dir "$DATA_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"
fi

# A running old process must not keep old Python code loaded during an update.
if systemctl is-active --quiet leomedflow.service 2>/dev/null; then
    systemctl stop leomedflow.service
fi

install -d -o root -g root -m 0755 "$APP_DIR"
install -d -o "$SERVICE_USER" -g "$SERVICE_USER" -m 0750 "$DATA_DIR" "$UPLOAD_DIR" "$BACKUP_DIR"

if [ "$SOURCE_DIR" != "$APP_DIR" ]; then
    for entry in app assets deployment migrations scripts templates manage.py migrate.sh .env.example requirements.txt API.md ARCHITECTURE.md CONTEXT.md CREDENTIALS.md DATABASE.md DEPLOYMENT.md HANDOVER.md MIGRATION.md PROCEDURES.md README.md; do
        [ -e "$SOURCE_DIR/$entry" ] || fail "required release item is missing: $entry"
        cp -a "$SOURCE_DIR/$entry" "$APP_DIR/"
    done
fi
chown -R root:root "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 0755 {} \;
find "$APP_DIR" -type f -exec chmod u=rw,go=r {} \;
chmod 0755 "$APP_DIR/manage.py" "$APP_DIR/migrate.sh" "$APP_DIR/scripts/"*.sh "$APP_DIR/scripts/leomedflow-health"
if [ -d "$APP_DIR/transfer" ]; then
    chown -R root:root "$APP_DIR/transfer"
    find "$APP_DIR/transfer" -type d -exec chmod 0700 {} \;
    find "$APP_DIR/transfer" -type f -exec chmod 0600 {} \;
fi

if [ -s "$SOURCE_DIR/transfer/leomedflow.db" ]; then
    SOURCE_DB=$SOURCE_DIR/transfer/leomedflow.db
else
    SOURCE_DB=$SOURCE_DIR/instance/leomedflow.db
fi
TARGET_DB=$DATA_DIR/leomedflow.db
if [ ! -e "$TARGET_DB" ] && [ -s "$SOURCE_DB" ]; then
    LEOMEDFLOW_SOURCE_DB=$SOURCE_DB LEOMEDFLOW_TARGET_DB=$TARGET_DB python3 - <<'PY' || fail "could not copy the SQLite database"
import os
import sqlite3
from pathlib import Path

source = Path(os.environ["LEOMEDFLOW_SOURCE_DB"])
target = Path(os.environ["LEOMEDFLOW_TARGET_DB"])
temporary = target.with_suffix(".db.importing")
with sqlite3.connect(source) as src:
    result = src.execute("PRAGMA integrity_check").fetchone()
    if not result or result[0] != "ok":
        raise SystemExit("source database integrity check failed")
    with sqlite3.connect(temporary) as dst:
        src.backup(dst)
os.replace(temporary, target)
PY
fi

if [ -d "$SOURCE_DIR/transfer/uploads" ]; then
    SOURCE_UPLOADS=$SOURCE_DIR/transfer/uploads
else
    SOURCE_UPLOADS=$SOURCE_DIR/uploads
fi
if [ -d "$SOURCE_UPLOADS" ]; then
    LEOMEDFLOW_SOURCE_UPLOADS=$SOURCE_UPLOADS LEOMEDFLOW_TARGET_UPLOADS=$UPLOAD_DIR python3 - <<'PY' || fail "could not copy uploads"
import os
import shutil
from pathlib import Path

source = Path(os.environ["LEOMEDFLOW_SOURCE_UPLOADS"])
target = Path(os.environ["LEOMEDFLOW_TARGET_UPLOADS"])
for item in source.rglob("*"):
    relative = item.relative_to(source)
    destination = target / relative
    if item.is_dir():
        destination.mkdir(parents=True, exist_ok=True)
    elif item.is_file() and not destination.exists():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, destination)
PY
fi
chown -R "$SERVICE_USER:$SERVICE_USER" "$DATA_DIR"
find "$DATA_DIR" -type d -exec chmod 0750 {} \;
find "$DATA_DIR" -type f -exec chmod 0640 {} \;

if [ ! -f "$ENV_FILE" ] && [ -f "$SOURCE_DIR/transfer/leomedflow.env" ]; then
    install -o root -g "$SERVICE_USER" -m 0640 "$SOURCE_DIR/transfer/leomedflow.env" "$ENV_FILE"
fi
if [ ! -f "$ENV_FILE" ]; then
    SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')
    umask 007
    {
        printf '%s\n' 'LEOMEDFLOW_ENV=production'
        printf 'LEOMEDFLOW_SECRET_KEY=%s\n' "$SECRET_KEY"
        printf '%s\n' 'LEOMEDFLOW_HOST=127.0.0.1'
        printf '%s\n' 'LEOMEDFLOW_PORT=8080'
        printf '%s\n' 'LEOMEDFLOW_INSTANCE=/var/lib/leomedflow'
        printf '%s\n' 'LEOMEDFLOW_DATABASE=/var/lib/leomedflow/leomedflow.db'
        printf '%s\n' 'LEOMEDFLOW_UPLOAD_DIR=/var/lib/leomedflow/uploads'
        printf '%s\n' 'LEOMEDFLOW_SESSION_HOURS=12'
        printf '%s\n' 'LEOMEDFLOW_MAX_UPLOAD_BYTES=10485760'
        printf '%s\n' 'LEOMEDFLOW_COOKIE_SECURE=1'
        printf '%s\n' 'PYTHONUNBUFFERED=1'
    } > "$ENV_FILE"
fi
chown root:"$SERVICE_USER" "$ENV_FILE"
chmod 0640 "$ENV_FILE"

install -o root -g root -m 0644 "$APP_DIR/deployment/leomedflow.service" "$UNIT_FILE"
install -o root -g root -m 0755 "$APP_DIR/scripts/leomedflow-health" "$HEALTH_BIN"
systemctl daemon-reload
systemctl enable leomedflow.service >/dev/null

if [ -s "$TARGET_DB" ]; then
    BACKUP_FILE=$BACKUP_DIR/pre-migrate-$(date -u +%Y%m%dT%H%M%SZ).db
    LEOMEDFLOW_SOURCE_DB=$TARGET_DB LEOMEDFLOW_TARGET_DB=$BACKUP_FILE python3 - <<'PY' || fail "could not create the pre-migration database backup"
import os
import sqlite3
with sqlite3.connect(os.environ["LEOMEDFLOW_SOURCE_DB"]) as src:
    with sqlite3.connect(os.environ["LEOMEDFLOW_TARGET_DB"]) as dst:
        src.backup(dst)
PY
    chown "$SERVICE_USER:$SERVICE_USER" "$BACKUP_FILE"
    chmod 0640 "$BACKUP_FILE"
fi

if command -v runuser >/dev/null 2>&1; then
    runuser -u "$SERVICE_USER" -- /bin/sh -c "set -a; . '$ENV_FILE'; set +a; exec /usr/bin/python3 '$APP_DIR/manage.py' migrate"
else
    su -s /bin/sh "$SERVICE_USER" -c "set -a; . '$ENV_FILE'; set +a; exec /usr/bin/python3 '$APP_DIR/manage.py' migrate"
fi

LEOMEDFLOW_TARGET_DB=$TARGET_DB python3 - <<'PY' || fail "installed database validation failed"
import os
import sqlite3
with sqlite3.connect(os.environ["LEOMEDFLOW_TARGET_DB"]) as conn:
    integrity = conn.execute("PRAGMA integrity_check").fetchone()
    foreign_keys = conn.execute("PRAGMA foreign_key_check").fetchall()
    migrations = conn.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0]
if not integrity or integrity[0] != "ok" or foreign_keys or migrations < 1:
    raise SystemExit(1)
PY

printf '%s\n' 'LEOMEDFLOW migration installed successfully.'
printf '%s\n' 'Run exactly:'
printf '%s\n' '  systemctl start leomedflow'
printf '%s\n' '  leomedflow-health'
