from __future__ import annotations

import base64
import hashlib
import json
import mimetypes
import os
import re
import sqlite3
import sys
import time
import traceback
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import config
from .db import audit, connect, migrate, now, row_dict, rows_dict, transaction
from .security import api_token_hash, hash_password, make_session, new_api_token, read_session, safe_filename, verify_password
from .services import (AppError, allocate, analytics, approve_quote, create_customer,
                       create_inventory, create_job, create_operator, create_quote,
                       dashboard, import_csv, job_detail, list_resources,
                       recommendations, transition_job, update_resource)

RATE_LIMIT: dict[str, list[float]] = {}


class Handler(BaseHTTPRequestHandler):
    server_version = "LEOMEDFLOW/1.0"

    def log_message(self, fmt: str, *args: object) -> None:
        sys.stdout.write(f"{self.log_date_time_string()} {self.client_address[0]} {fmt % args}\n")

    def _headers(self, status: int, content_type: str = "application/json; charset=utf-8", length: int | None = None,
                 extra: dict[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        if length is not None: self.send_header("Content-Length", str(length))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Permissions-Policy", "geolocation=(self), camera=()")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
        self.send_header("Cache-Control", "no-store" if content_type.startswith("application/json") else "private, max-age=300")
        for key, value in (extra or {}).items(): self.send_header(key, value)
        self.end_headers()

    def json_response(self, data: object, status: int = 200, extra: dict[str, str] | None = None) -> None:
        # A mutation must be durable before the client receives its response;
        # otherwise an immediate follow-up request can race the transaction exit.
        if self.command not in ("GET", "HEAD") and getattr(self, "_active_conn", None) is not None:
            try: self._active_conn.commit()
            except sqlite3.ProgrammingError: pass
        raw = json.dumps(data, default=str, separators=(",", ":")).encode()
        self._headers(status, length=len(raw), extra=extra); self.wfile.write(raw)

    def error_response(self, message: str, status: int = 400, code: str = "error", details: object = None) -> None:
        self.json_response({"error": {"code": code, "message": message, "details": details}}, status)

    def read_body(self) -> dict:
        size = int(self.headers.get("Content-Length", "0"))
        if size > config.MAX_UPLOAD_BYTES * 1.4: raise AppError("Request exceeds upload limit", 413, "too_large")
        raw = self.rfile.read(size) if size else b""
        ctype = self.headers.get("Content-Type", "")
        if "application/json" in ctype:
            try: return json.loads(raw or b"{}")
            except json.JSONDecodeError as exc: raise AppError("Malformed JSON") from exc
        if "application/x-www-form-urlencoded" in ctype:
            return {k:v[-1] for k,v in parse_qs(raw.decode()).items()}
        return {"raw": raw}

    def cookie_session(self) -> dict | None:
        cookie = SimpleCookie(self.headers.get("Cookie", "")); morsel = cookie.get("lmf_session")
        return read_session(morsel.value if morsel else None)

    def current_user(self, conn: sqlite3.Connection, required: bool = True) -> dict | None:
        auth = self.headers.get("Authorization", "")
        row = None; session = None; auth_type = None
        if auth.startswith("Bearer "):
            token_hash = api_token_hash(auth[7:])
            row = conn.execute("""SELECT u.*,r.name role FROM api_tokens t JOIN users u ON u.id=t.user_id JOIN roles r ON r.id=u.role_id
                WHERE t.token_hash=? AND t.revoked_at IS NULL AND t.expires_at>? AND u.active=1""", (token_hash, now())).fetchone()
            auth_type = "bearer"
        else:
            session = self.cookie_session()
            if session: row = conn.execute("SELECT u.*,r.name role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=? AND u.active=1", (session["uid"],)).fetchone()
            auth_type = "session"
        if not row:
            if required: raise AppError("Authentication required", 401, "unauthorized")
            return None
        user = row_dict(row); user["auth_type"] = auth_type; user["csrf"] = session.get("csrf") if session else None
        if auth_type=="bearer": user["token_hash"]=token_hash
        return user

    def protect(self, user: dict, admin: bool = False) -> None:
        if admin and user["role"] != "Admin": raise AppError("Administrator access required", 403, "forbidden")
        if self.command not in ("GET", "HEAD") and user["auth_type"] == "session":
            if not self.headers.get("X-CSRF-Token") or self.headers["X-CSRF-Token"] != user["csrf"]:
                raise AppError("CSRF token is missing or invalid", 403, "csrf_failed")

    def rate_limit(self, key: str, limit: int = 10, window: int = 60) -> None:
        current=time.time(); bucket=RATE_LIMIT.setdefault(key,[]); bucket[:]=[t for t in bucket if t>current-window]
        if len(bucket)>=limit: raise AppError("Too many attempts; try again shortly",429,"rate_limited")
        bucket.append(current)

    def serve_file(self, path: Path, content_type: str | None = None) -> None:
        if not path.exists() or not path.is_file(): raise AppError("Not found",404,"not_found")
        raw=path.read_bytes(); self._headers(200,content_type or mimetypes.guess_type(path.name)[0] or "application/octet-stream",len(raw)); self.wfile.write(raw)

    def do_GET(self) -> None:
        self.dispatch()
    def do_POST(self) -> None:
        self.dispatch()
    def do_PATCH(self) -> None:
        self.dispatch()
    def do_DELETE(self) -> None:
        self.dispatch()

    def dispatch(self) -> None:
        parsed=urlparse(self.path); path=parsed.path; params={k:v[-1] for k,v in parse_qs(parsed.query).items()}
        try:
            if path in ("/", "/admin", "/operator"):
                return self.serve_file(config.ROOT/"templates"/"index.html","text/html; charset=utf-8")
            if path.startswith("/assets/"):
                asset=(config.ROOT/path.lstrip("/")).resolve()
                if config.ROOT/"assets" not in asset.parents: raise AppError("Not found",404)
                return self.serve_file(asset)
            if path=="/health":
                checks={"database":"error","uploads":"error"}; migration=None
                try:
                    with connect() as health_conn:
                        health_conn.execute("SELECT 1").fetchone()
                        row=health_conn.execute("SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1").fetchone()
                        migration=row[0] if row else None
                    checks["database"]="ok"
                    if config.UPLOAD_DIR.is_dir() and os.access(config.UPLOAD_DIR,os.W_OK): checks["uploads"]="ok"
                except (OSError,sqlite3.Error):
                    pass
                healthy=all(value=="ok" for value in checks.values())
                return self.json_response({"status":"ok" if healthy else "degraded","service":"LEOMEDFLOW","version":"1.0.0","time":now(),"checks":checks,"migration":migration},200 if healthy else 503)
            if not path.startswith("/api/v1/"): raise AppError("Not found",404,"not_found")
            with transaction() as conn:
                self._active_conn=conn
                if path=="/api/v1/auth/login" and self.command=="POST": return self.login(conn)
                user=self.current_user(conn); assert user
                if path=="/api/v1/auth/logout" and self.command=="POST":
                    self.protect(user)
                    if user["auth_type"]=="bearer": conn.execute("UPDATE api_tokens SET revoked_at=? WHERE token_hash=?",(now(),user["token_hash"]))
                    audit(conn,user["id"],"logout","session")
                    return self.json_response({"ok":True},extra={"Set-Cookie":"lmf_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"})
                if path=="/api/v1/me" and self.command=="GET":
                    return self.json_response({"user":{"id":user["id"],"username":user["username"],"display_name":user["display_name"],"role":user["role"]},"csrf_token":user.get("csrf")})
                if path=="/api/v1/dashboard" and self.command=="GET": return self.json_response(dashboard(conn,user))
                if path=="/api/v1/analytics" and self.command=="GET": self.protect(user,True); return self.json_response(analytics(conn,params))
                if path=="/api/v1/recommendations" and self.command=="GET":
                    self.protect(user,True); return self.json_response(recommendations(conn,params.get("start_at",now()),params.get("end_at",(datetime.now(timezone.utc)+timedelta(days=1)).isoformat()),int(params["location_id"]) if params.get("location_id") else None,params.get("category")))
                match=re.fullmatch(r"/api/v1/(operators|devices|consumables|customers|quotations|invoices|jobs|notifications|audit|maintenance|collections)",path)
                if match:
                    resource=match.group(1)
                    if self.command=="GET": return self.json_response({"items":list_resources(conn,resource,user,params)})
                    self.protect(user,True); data=self.read_body()
                    if self.command=="POST": return self.create_resource(conn,resource,data,user)
                match=re.fullmatch(r"/api/v1/(operators|devices|consumables|customers|quotations|invoices)/(\d+)",path)
                if match and self.command=="PATCH":
                    self.protect(user,True); return self.json_response(update_resource(conn,match.group(1),int(match.group(2)),self.read_body(),user["id"]))
                match=re.fullmatch(r"/api/v1/operators/(\d+)/password",path)
                if match and self.command=="POST":
                    self.protect(user,True); data=self.read_body(); require_keys(data,"password")
                    op=conn.execute("SELECT user_id FROM operators WHERE id=?",(int(match.group(1)),)).fetchone()
                    if not op: raise AppError("Operator not found",404)
                    conn.execute("UPDATE users SET password_hash=?,updated_at=? WHERE id=?",(hash_password(data["password"]),now(),op["user_id"]))
                    conn.execute("UPDATE api_tokens SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL",(now(),op["user_id"]))
                    audit(conn,user["id"],"password_reset","operator",match.group(1)); return self.json_response({"ok":True})
                match=re.fullmatch(r"/api/v1/quotations/(\d+)/approve",path)
                if match and self.command=="POST": self.protect(user,True); return self.json_response(approve_quote(conn,int(match.group(1)),user["id"]))
                match=re.fullmatch(r"/api/v1/quotations/(\d+)/convert",path)
                if match and self.command=="POST": self.protect(user,True); return self.json_response(create_job(conn,int(match.group(1)),self.read_body(),user["id"]),201)
                match=re.fullmatch(r"/api/v1/jobs/(\d+)",path)
                if match and self.command=="GET": return self.json_response(job_detail(conn,int(match.group(1)),user))
                match=re.fullmatch(r"/api/v1/jobs/(\d+)/allocations",path)
                if match and self.command=="POST": self.protect(user,True); return self.json_response(allocate(conn,int(match.group(1)),self.read_body(),user["id"]),201)
                match=re.fullmatch(r"/api/v1/jobs/(\d+)/transition",path)
                if match and self.command=="POST":
                    self.protect(user); data=self.read_body(); return self.json_response(transition_job(conn,int(match.group(1)),data.get("status",""),data,user))
                match=re.fullmatch(r"/api/v1/jobs/(\d+)/proofs",path)
                if match and self.command=="POST": self.protect(user); return self.upload_proof(conn,int(match.group(1)),self.read_body(),user)
                match=re.fullmatch(r"/api/v1/(devices|consumables)/(\d+)/history",path)
                if match and self.command=="GET":
                    kind=match.group(1)[:-1]; rid=int(match.group(2)); return self.json_response({"items":rows_dict(conn.execute("SELECT * FROM inventory_history WHERE resource_type=? AND resource_id=? ORDER BY created_at DESC",(kind,rid)).fetchall())})
                match=re.fullmatch(r"/api/v1/devices/(\d+)/maintenance",path)
                if match and self.command=="POST": self.protect(user,True); return self.create_maintenance(conn,int(match.group(1)),self.read_body(),user)
                match=re.fullmatch(r"/api/v1/notifications/(\d+)/read",path)
                if match and self.command=="POST":
                    self.protect(user); conn.execute("UPDATE notifications SET read_at=? WHERE id=? AND user_id=?",(now(),int(match.group(1)),user["id"])); return self.json_response({"ok":True})
                if path=="/api/v1/imports" and self.command=="POST": self.protect(user,True); return self.handle_import(conn,self.read_body(),user)
                if path=="/api/v1/attachments":
                    if self.command=="GET":
                        require_keys(params,"entity_type","entity_id"); return self.json_response({"items":rows_dict(conn.execute("SELECT id,entity_type,entity_id,original_name,mime_type,file_sha256,uploaded_by,created_at FROM attachments WHERE entity_type=? AND entity_id=? ORDER BY created_at DESC",(params["entity_type"],params["entity_id"])).fetchall())})
                    self.protect(user,True); return self.upload_attachment(conn,self.read_body(),user)
                match=re.fullmatch(r"/api/v1/(proofs|attachments)/(\d+)/download",path)
                if match and self.command=="GET": return self.download_upload(conn,match.group(1),int(match.group(2)),user)
                if path=="/api/v1/settings/statuses":
                    if self.command=="GET": return self.json_response({"items":rows_dict(conn.execute("SELECT * FROM status_definitions WHERE active=1 ORDER BY entity_type,sort_order").fetchall())})
                    self.protect(user,True); d=self.read_body(); require_keys(d,"entity_type","name"); conn.execute("INSERT INTO status_definitions(entity_type,name,color,terminal,sort_order) VALUES (?,?,?,?,?)",(d["entity_type"],d["name"],d.get("color","#64748b"),int(bool(d.get("terminal"))),int(d.get("sort_order",0)))); return self.json_response({"ok":True},201)
                if path=="/api/v1/settings/custom-fields":
                    if self.command=="GET": return self.json_response({"items":rows_dict(conn.execute("SELECT * FROM custom_field_definitions WHERE active=1").fetchall())})
                    self.protect(user,True); d=self.read_body(); require_keys(d,"entity_type","field_key","label","field_type"); conn.execute("INSERT INTO custom_field_definitions(entity_type,field_key,label,field_type,required,options) VALUES (?,?,?,?,?,?)",(d["entity_type"],d["field_key"],d["label"],d["field_type"],int(bool(d.get("required"))),json.dumps(d.get("options",[])))); return self.json_response({"ok":True},201)
                raise AppError("Endpoint not found",404,"not_found")
        except AppError as exc: self.error_response(exc.message,exc.status,exc.code)
        except sqlite3.IntegrityError as exc: self.error_response("The operation conflicts with existing data",409,"database_conflict",str(exc))
        except BrokenPipeError: pass
        except Exception as exc:
            traceback.print_exc(); self.error_response("Internal server error",500,"internal_error",str(exc) if os.getenv("LEOMEDFLOW_DEBUG")=="1" else None)

    def login(self, conn: sqlite3.Connection) -> None:
        self.rate_limit("login:"+self.client_address[0]); data=self.read_body(); username=str(data.get("username","")).strip().lower()
        row=conn.execute("SELECT u.*,r.name role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.username=? AND u.active=1",(username,)).fetchone()
        if not row or not verify_password(str(data.get("password","")),row["password_hash"]):
            audit(conn,row["id"] if row else None,"login_failed","user",row["id"] if row else username,ip=self.client_address[0],user_agent=self.headers.get("User-Agent")); raise AppError("Invalid username or password",401,"invalid_credentials")
        session,csrf=make_session(row["id"],row["role"]); token,token_hash=new_api_token(); stamp=now(); expires=(datetime.now(timezone.utc)+timedelta(days=30)).replace(microsecond=0).isoformat()
        conn.execute("INSERT INTO api_tokens(user_id,token_hash,expires_at,created_at) VALUES (?,?,?,?)",(row["id"],token_hash,expires,stamp)); conn.execute("UPDATE users SET last_login_at=?,updated_at=? WHERE id=?",(stamp,stamp,row["id"])); audit(conn,row["id"],"login","user",row["id"],ip=self.client_address[0],user_agent=self.headers.get("User-Agent"))
        cookie=f"lmf_session={session}; Path=/; HttpOnly; SameSite=Strict; Max-Age={config.SESSION_HOURS*3600}"
        if os.getenv("LEOMEDFLOW_COOKIE_SECURE","0")=="1": cookie+="; Secure"
        self.json_response({"user":{"id":row["id"],"display_name":row["display_name"],"role":row["role"]},"csrf_token":csrf,"api_token":token,"token_expires_at":expires},extra={"Set-Cookie":cookie})

    def create_resource(self,conn,resource,data,user):
        if resource=="operators": item=create_operator(conn,data,user["id"])
        elif resource=="devices": item=create_inventory(conn,"device",data,user["id"])
        elif resource=="consumables": item=create_inventory(conn,"consumable",data,user["id"])
        elif resource=="customers": item=create_customer(conn,data,user["id"])
        elif resource=="quotations": item=create_quote(conn,data,user["id"])
        else: raise AppError("Creation is not supported for this resource",405)
        return self.json_response(item,201)

    def upload_proof(self,conn,job_id,data,user):
        require_keys(data,"filename","content_base64","kind","captured_at")
        job=job_detail(conn,job_id,user)
        if user["role"]=="Admin": operator_id=data.get("operator_id") or job["operator_id"]
        else: operator_id=conn.execute("SELECT id FROM operators WHERE user_id=?",(user["id"],)).fetchone()[0]
        if not operator_id: raise AppError("A proof must be linked to an operator")
        filename=safe_filename(data["filename"]); ext=filename.rsplit(".",1)[-1].lower() if "." in filename else ""
        if ext not in config.ALLOWED_EXTENSIONS-{"csv","xlsx"}: raise AppError("Unsupported proof file type")
        try: content=base64.b64decode(data["content_base64"],validate=True)
        except Exception as exc: raise AppError("Invalid base64 file content") from exc
        if not content or len(content)>config.MAX_UPLOAD_BYTES: raise AppError("Proof file is empty or exceeds the size limit",413)
        signature={"pdf":b"%PDF","png":b"\x89PNG","jpg":b"\xff\xd8","jpeg":b"\xff\xd8","webp":b"RIFF"}.get(ext)
        if signature and not content.startswith(signature): raise AppError("File contents do not match its extension")
        digest=hashlib.sha256(content).hexdigest(); stored=f"{job_id}_{int(time.time())}_{digest[:12]}.{ext}"; target=config.UPLOAD_DIR/stored; target.write_bytes(content); os.chmod(target,0o640)
        captured=str(data["captured_at"]); latitude=data.get("latitude"); longitude=data.get("longitude")
        if latitude is not None and not -90<=float(latitude)<=90: raise AppError("Invalid latitude")
        if longitude is not None and not -180<=float(longitude)<=180: raise AppError("Invalid longitude")
        serials=[a.get("serial_number") for a in job["allocations"]]
        cur=conn.execute("INSERT INTO proofs(job_id,collection_id,operator_id,kind,file_path,original_name,mime_type,file_sha256,captured_at,latitude,longitude,metadata,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (job_id,data.get("collection_id"),operator_id,data["kind"],stored,filename,mimetypes.guess_type(filename)[0] or "application/octet-stream",digest,captured,latitude,longitude,json.dumps({"job_number":job["job_number"],"serial_numbers":serials,"operator_user_id":user["id"]}),now()))
        audit(conn,user["id"],"upload_proof","job",job_id,after={"proof_id":cur.lastrowid,"sha256":digest,"gps":[latitude,longitude]})
        return self.json_response({"id":cur.lastrowid,"sha256":digest,"captured_at":captured,"serial_numbers":serials},201)

    def create_maintenance(self,conn,device_id,data,user):
        dev=row_dict(conn.execute("SELECT * FROM devices WHERE id=?",(device_id,)).fetchone())
        if not dev: raise AppError("Device not found",404)
        stamp=now(); cur=conn.execute("INSERT INTO maintenance(device_id,kind,status,scheduled_at,started_at,cost,notes,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (device_id,data.get("kind","Preventive"),data.get("status","Scheduled"),data.get("scheduled_at"),stamp if data.get("status")=="In Progress" else None,float(data.get("cost",0)),data.get("notes"),stamp,stamp))
        if data.get("status") in ("In Progress","Scheduled"): conn.execute("UPDATE devices SET status='Maintenance',updated_at=? WHERE id=?",(stamp,device_id))
        audit(conn,user["id"],"maintenance_create","device",device_id,dev,{"maintenance_id":cur.lastrowid}); return self.json_response({"id":cur.lastrowid},201)

    def handle_import(self,conn,data,user):
        require_keys(data,"entity_type","filename","content_base64")
        if not str(data["filename"]).lower().endswith((".csv",".xlsx")): raise AppError("Import file must be CSV or XLSX")
        try: content=base64.b64decode(data["content_base64"],validate=True)
        except Exception as exc: raise AppError("Invalid base64 content") from exc
        if len(content)>config.MAX_UPLOAD_BYTES: raise AppError("Import exceeds size limit",413)
        return self.json_response(import_csv(conn,data["entity_type"],safe_filename(data["filename"]),content,user["id"]),201)

    def upload_attachment(self,conn,data,user):
        require_keys(data,"entity_type","entity_id","filename","content_base64")
        if data["entity_type"] not in ("quotation","invoice","job","device","consumable","customer"): raise AppError("Unsupported attachment entity")
        filename=safe_filename(data["filename"]); ext=filename.rsplit(".",1)[-1].lower() if "." in filename else ""
        if ext not in config.ALLOWED_EXTENSIONS: raise AppError("Unsupported attachment type")
        try: content=base64.b64decode(data["content_base64"],validate=True)
        except Exception as exc: raise AppError("Invalid base64 file content") from exc
        if not content or len(content)>config.MAX_UPLOAD_BYTES: raise AppError("Attachment is empty or exceeds the size limit",413)
        digest=hashlib.sha256(content).hexdigest(); stored=f"attachment_{data['entity_type']}_{int(data['entity_id'])}_{int(time.time())}_{digest[:12]}.{ext}"
        target=config.UPLOAD_DIR/stored; target.write_bytes(content); os.chmod(target,0o640)
        cur=conn.execute("INSERT INTO attachments(entity_type,entity_id,file_path,original_name,mime_type,file_sha256,uploaded_by,created_at) VALUES (?,?,?,?,?,?,?,?)",
            (data["entity_type"],int(data["entity_id"]),stored,filename,mimetypes.guess_type(filename)[0] or "application/octet-stream",digest,user["id"],now()))
        audit(conn,user["id"],"upload_attachment",data["entity_type"],data["entity_id"],after={"attachment_id":cur.lastrowid,"sha256":digest})
        return self.json_response({"id":cur.lastrowid,"sha256":digest,"original_name":filename},201)

    def download_upload(self,conn,kind,upload_id,user):
        table="proofs" if kind=="proofs" else "attachments"; row=conn.execute(f"SELECT * FROM {table} WHERE id=?",(upload_id,)).fetchone()
        if not row: raise AppError("Upload not found",404)
        if kind=="proofs" and user["role"]=="Operator": job_detail(conn,row["job_id"],user)
        if kind=="attachments" and user["role"]=="Operator" and row["entity_type"]=="job": job_detail(conn,row["entity_id"],user)
        elif kind=="attachments" and user["role"]=="Operator": raise AppError("Administrator access required",403)
        path=(config.UPLOAD_DIR/row["file_path"]).resolve()
        if config.UPLOAD_DIR.resolve() not in path.parents: raise AppError("Invalid upload path",500)
        return self.serve_file(path,row["mime_type"])


def require_keys(data: dict, *keys: str) -> None:
    missing=[k for k in keys if data.get(k) in (None,"")]
    if missing: raise AppError("Missing required fields: "+", ".join(missing))


def run(host: str = config.HOST, port: int = config.PORT) -> None:
    if config.ENVIRONMENT.lower()=="production" and config.SECRET_KEY=="development-only-change-me":
        raise RuntimeError("LEOMEDFLOW_SECRET_KEY must be set in production")
    config.ensure_directories(); applied=migrate();
    if applied: print("Applied migrations:",", ".join(applied))
    server=ThreadingHTTPServer((host,port),Handler)
    print(f"LEOMEDFLOW running on http://{host}:{port}")
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()


if __name__=="__main__": run()
