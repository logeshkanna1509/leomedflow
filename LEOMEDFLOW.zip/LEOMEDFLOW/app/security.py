from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from typing import Any

from . import config

PBKDF2_ITERATIONS = 310_000


def hash_password(password: str) -> str:
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters")
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, iterations, salt64, digest64 = encoded.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), base64.urlsafe_b64decode(salt64), int(iterations))
        return hmac.compare_digest(actual, base64.urlsafe_b64decode(digest64))
    except (ValueError, TypeError):
        return False


def _sign(data: bytes) -> str:
    return base64.urlsafe_b64encode(hmac.new(config.SECRET_KEY.encode(), data, hashlib.sha256).digest()).decode().rstrip("=")


def make_session(user_id: int, role: str) -> tuple[str, str]:
    csrf = secrets.token_urlsafe(24)
    payload = {"uid": user_id, "role": role, "csrf": csrf, "exp": int(time.time()) + config.SESSION_HOURS * 3600}
    body = base64.urlsafe_b64encode(json.dumps(payload, separators=(",", ":")).encode()).decode().rstrip("=")
    return f"{body}.{_sign(body.encode())}", csrf


def read_session(token: str | None) -> dict[str, Any] | None:
    if not token or "." not in token:
        return None
    body, signature = token.rsplit(".", 1)
    if not hmac.compare_digest(signature, _sign(body.encode())):
        return None
    try:
        payload = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)))
        return payload if payload.get("exp", 0) >= time.time() else None
    except (ValueError, json.JSONDecodeError):
        return None


def new_api_token() -> tuple[str, str]:
    token = "lmf_" + secrets.token_urlsafe(40)
    return token, hashlib.sha256(token.encode()).hexdigest()


def api_token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def safe_filename(name: str) -> str:
    name = name.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    stem, dot, ext = name.rpartition(".")
    clean = "".join(c if c.isalnum() or c in "-_" else "_" for c in (stem or ext))[:80] or "upload"
    suffix = (ext if dot else "").lower()
    return clean + (("." + suffix) if suffix else "")
