from __future__ import annotations

import csv
import io
import json
import math
import sqlite3
import zipfile
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta, timezone
from typing import Any

from .db import audit, now, row_dict, rows_dict


class AppError(Exception):
    def __init__(self, message: str, status: int = 400, code: str = "validation_error"):
        super().__init__(message)
        self.message, self.status, self.code = message, status, code


DEVICE_STATUSES = ["Available", "Allocated", "In Use", "Shipped", "Received", "Returned", "Broken", "Maintenance", "Lost", "Retired"]
CONSUMABLE_STATUSES = ["Available", "Allocated", "In Use", "Consumed", "Returned", "Damaged", "Expired", "Lost"]
JOB_TRANSITIONS = {
    "Scheduled": {"Allocated", "Cancelled"},
    "Allocated": {"Shipped", "In Treatment", "Cancelled"},
    "Shipped": {"Received", "Cancelled"},
    "Received": {"In Treatment", "Cancelled"},
    "In Treatment": {"Awaiting Collection", "Cancelled"},
    "Awaiting Collection": {"Collected"},
    "Collected": {"Completed"},
    "Completed": set(), "Cancelled": set(),
}


def require(data: dict[str, Any], *fields: str) -> None:
    missing = [f for f in fields if data.get(f) in (None, "")]
    if missing:
        raise AppError("Missing required fields: " + ", ".join(missing))


def iso(value: Any, field: str = "date") -> str:
    try:
        text = str(value).replace("Z", "+00:00")
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat()
    except (ValueError, TypeError):
        raise AppError(f"{field} must be an ISO-8601 date/time")


def calculate_quote(data: dict[str, Any]) -> tuple[float, float, float]:
    subtotal = round(float(data.get("subtotal", 0)), 2)
    tax_rate = float(data.get("tax_rate", 0))
    discount = round(float(data.get("discount", 0)), 2)
    if subtotal < 0 or discount < 0 or not (0 <= tax_rate <= 100):
        raise AppError("Pricing values are outside the allowed range")
    tax = round(max(0, subtotal - discount) * tax_rate / 100, 2)
    return subtotal, tax, round(max(0, subtotal - discount) + tax, 2)


def create_location(conn: sqlite3.Connection, data: dict[str, Any]) -> int:
    require(data, "district", "state", "country")
    cur = conn.execute(
        "INSERT INTO locations(name,address,district,state,country,latitude,longitude,created_at) VALUES (?,?,?,?,?,?,?,?)",
        (data.get("name") or data["district"], data.get("address"), data["district"], data["state"], data["country"],
         data.get("latitude"), data.get("longitude"), now()),
    )
    return cur.lastrowid


def list_resources(conn: sqlite3.Connection, resource: str, user: dict[str, Any], params: dict[str, str]) -> list[dict[str, Any]]:
    definitions = {
        "operators": ("""SELECT o.*,u.username,u.display_name,u.email,l.name location_name,l.district,l.state,l.country,
            (SELECT COUNT(*) FROM jobs j WHERE j.operator_id=o.id AND j.status NOT IN ('Completed','Cancelled')) workload
            FROM operators o JOIN users u ON u.id=o.user_id LEFT JOIN locations l ON l.id=o.location_id""", "o"),
        "devices": ("""SELECT d.*,l.name location_name,l.district,l.state,l.country,o.employee_code operator_code,j.job_number
            FROM devices d LEFT JOIN locations l ON l.id=d.location_id LEFT JOIN operators o ON o.id=d.current_operator_id LEFT JOIN jobs j ON j.id=d.current_job_id""", "d"),
        "consumables": ("""SELECT c.*,l.name location_name,l.district,l.state,l.country,o.employee_code operator_code,j.job_number
            FROM consumables c LEFT JOIN locations l ON l.id=c.location_id LEFT JOIN operators o ON o.id=c.current_operator_id LEFT JOIN jobs j ON j.id=c.current_job_id""", "c"),
        "customers": ("""SELECT c.*,l.name location_name,l.district,l.state,l.country
            FROM customers c LEFT JOIN locations l ON l.id=c.service_location_id""", "c"),
        "quotations": ("""SELECT q.*,c.name customer_name FROM quotations q JOIN customers c ON c.id=q.customer_id""", "q"),
        "invoices": ("""SELECT i.*,c.name customer_name,j.job_number FROM invoices i JOIN customers c ON c.id=i.customer_id LEFT JOIN jobs j ON j.id=i.job_id""", "i"),
        "jobs": ("""SELECT j.*,c.name customer_name,u.display_name operator_name,o.employee_code,l.district,l.state,l.country,
            (SELECT COUNT(*) FROM allocations a WHERE a.job_id=j.id AND a.status NOT IN ('Returned','Cancelled')) allocation_count
            FROM jobs j JOIN customers c ON c.id=j.customer_id LEFT JOIN operators o ON o.id=j.operator_id
            LEFT JOIN users u ON u.id=o.user_id LEFT JOIN locations l ON l.id=j.service_location_id""", "j"),
        "notifications": ("SELECT * FROM notifications n", "n"),
        "audit": ("""SELECT a.*,u.display_name actor_name FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_user_id""", "a"),
        "maintenance": ("SELECT m.*,d.serial_number FROM maintenance m JOIN devices d ON d.id=m.device_id", "m"),
        "collections": ("""SELECT c.*,j.job_number,l.district,l.state,u.display_name operator_name FROM collections c
            JOIN jobs j ON j.id=c.job_id LEFT JOIN locations l ON l.id=c.location_id LEFT JOIN operators o ON o.id=c.assigned_operator_id LEFT JOIN users u ON u.id=o.user_id""", "c"),
    }
    if resource not in definitions:
        raise AppError("Unknown resource", 404, "not_found")
    sql, alias = definitions[resource]
    clauses: list[str] = []
    values: list[Any] = []
    if user["role"] == "Operator":
        op = conn.execute("SELECT id FROM operators WHERE user_id=?", (user["id"],)).fetchone()
        operator_id = op[0] if op else -1
        if resource == "jobs": clauses.append("j.operator_id=?"); values.append(operator_id)
        elif resource == "notifications": clauses.append("n.user_id=?"); values.append(user["id"])
        elif resource == "devices": clauses.append("d.current_operator_id=?"); values.append(operator_id)
        elif resource == "consumables": clauses.append("c.current_operator_id=?"); values.append(operator_id)
        elif resource == "collections": clauses.append("c.assigned_operator_id=?"); values.append(operator_id)
        else: raise AppError("Administrator access required", 403, "forbidden")
    if params.get("status"):
        clauses.append(f"{alias}.status=?"); values.append(params["status"])
    if params.get("q"):
        allowed_search = {"devices":"serial_number", "consumables":"name", "customers":"name", "jobs":"job_number", "quotations":"quote_number", "operators":"employee_code"}
        if resource in allowed_search:
            clauses.append(f"{alias}.{allowed_search[resource]} LIKE ?"); values.append(f"%{params['q']}%")
    if clauses: sql += " WHERE " + " AND ".join(clauses)
    sql += f" ORDER BY {alias}.id DESC LIMIT 500"
    return rows_dict(conn.execute(sql, values).fetchall())


def create_operator(conn: sqlite3.Connection, data: dict[str, Any], actor: int) -> dict[str, Any]:
    from .security import hash_password
    require(data, "username", "password", "display_name", "employee_code")
    location_id = data.get("location_id") or (create_location(conn, data["location"]) if data.get("location") else None)
    role_id = conn.execute("SELECT id FROM roles WHERE name='Operator'").fetchone()[0]
    stamp = now()
    try:
        cur = conn.execute("INSERT INTO users(role_id,username,password_hash,display_name,email,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
            (role_id, data["username"].strip().lower(), hash_password(data["password"]), data["display_name"], data.get("email"), stamp, stamp))
        user_id = cur.lastrowid
        cur = conn.execute("""INSERT INTO operators(user_id,employee_code,phone,availability_status,location_id,max_concurrent_jobs,skills,custom_fields,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?)""", (user_id, data["employee_code"], data.get("phone"), data.get("availability_status", "Available"),
            location_id, int(data.get("max_concurrent_jobs", 3)), json.dumps(data.get("skills", [])), json.dumps(data.get("custom_fields", {})), stamp, stamp))
    except sqlite3.IntegrityError as exc:
        raise AppError("Username or employee code already exists", 409, "duplicate") from exc
    result = row_dict(conn.execute("SELECT * FROM operators WHERE id=?", (cur.lastrowid,)).fetchone())
    audit(conn, actor, "create", "operator", cur.lastrowid, after=result)
    return result  # type: ignore[return-value]


def create_inventory(conn: sqlite3.Connection, kind: str, data: dict[str, Any], actor: int) -> dict[str, Any]:
    stamp = now()
    location_id = data.get("location_id") or (create_location(conn, data["location"]) if data.get("location") else None)
    try:
        if kind == "device":
            require(data, "serial_number", "model", "category")
            status = data.get("status", "Available")
            if status not in DEVICE_STATUSES: raise AppError("Invalid device status")
            cur = conn.execute("""INSERT INTO devices(serial_number,model,category,status,location_id,purchase_cost,maintenance_due_at,custom_fields,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?)""", (data["serial_number"], data["model"], data["category"], status, location_id,
                float(data.get("purchase_cost", 0)), data.get("maintenance_due_at"), json.dumps(data.get("custom_fields", {})), stamp, stamp))
        else:
            require(data, "sku", "name")
            status = data.get("status", "Available")
            if status not in CONSUMABLE_STATUSES: raise AppError("Invalid consumable status")
            cur = conn.execute("""INSERT INTO consumables(serial_number,sku,name,batch_number,quantity,unit,unit_cost,status,expiry_date,location_id,custom_fields,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""", (data.get("serial_number") or None, data["sku"], data["name"], data.get("batch_number"),
                float(data.get("quantity", 1)), data.get("unit", "unit"), float(data.get("unit_cost", 0)), status,
                data.get("expiry_date"), location_id, json.dumps(data.get("custom_fields", {})), stamp, stamp))
    except sqlite3.IntegrityError as exc:
        raise AppError("Serial number already exists", 409, "duplicate_serial") from exc
    item = row_dict(conn.execute(f"SELECT * FROM {'devices' if kind == 'device' else 'consumables'} WHERE id=?", (cur.lastrowid,)).fetchone())
    conn.execute("INSERT INTO inventory_history(resource_type,resource_id,to_status,to_location_id,notes,changed_by,created_at) VALUES (?,?,?,?,?,?,?)",
        (kind, cur.lastrowid, status, location_id, "Inventory created", actor, stamp))
    audit(conn, actor, "create", kind, cur.lastrowid, after=item)
    return item  # type: ignore[return-value]


def create_customer(conn: sqlite3.Connection, data: dict[str, Any], actor: int) -> dict[str, Any]:
    require(data, "code", "name")
    location_id = data.get("service_location_id") or (create_location(conn, data["location"]) if data.get("location") else None)
    stamp = now()
    try:
        cur = conn.execute("INSERT INTO customers(code,name,email,phone,billing_location_id,service_location_id,custom_fields,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (data["code"], data["name"], data.get("email"), data.get("phone"), data.get("billing_location_id") or location_id,
             location_id, json.dumps(data.get("custom_fields", {})), stamp, stamp))
    except sqlite3.IntegrityError as exc: raise AppError("Customer code already exists", 409, "duplicate") from exc
    item = row_dict(conn.execute("SELECT * FROM customers WHERE id=?", (cur.lastrowid,)).fetchone())
    audit(conn, actor, "create", "customer", cur.lastrowid, after=item)
    return item  # type: ignore[return-value]


def update_resource(conn: sqlite3.Connection, resource: str, resource_id: int, data: dict[str, Any], actor: int) -> dict[str, Any]:
    tables={"devices":"devices","consumables":"consumables","customers":"customers","operators":"operators","quotations":"quotations","invoices":"invoices"}
    allowed={
        "devices":{"model","category","status","location_id","purchase_cost","maintenance_due_at","custom_fields"},
        "consumables":{"sku","name","batch_number","quantity","unit","unit_cost","status","expiry_date","location_id","custom_fields"},
        "customers":{"name","email","phone","billing_location_id","service_location_id","custom_fields"},
        "operators":{"phone","availability_status","location_id","max_concurrent_jobs","skills","custom_fields"},
        "quotations":{"treatment","description","duration_days","treatment_start","subtotal","tax_rate","discount","cost_estimate","payment_status","line_items"},
        "invoices":{"status","payment_status","due_date"},
    }
    if resource not in tables: raise AppError("Resource cannot be updated",405)
    table=tables[resource]; before=row_dict(conn.execute(f"SELECT * FROM {table} WHERE id=?",(resource_id,)).fetchone())
    if not before: raise AppError("Record not found",404)
    if resource=="quotations" and before["status"] not in ("Draft","Sent"): raise AppError("Only Draft or Sent quotations can be edited",409)
    if data.get("location"):
        data["location_id"]=create_location(conn,data["location"])
    if resource=="devices" and data.get("status") not in (None,*DEVICE_STATUSES): raise AppError("Invalid device status")
    if resource=="consumables" and data.get("status") not in (None,*CONSUMABLE_STATUSES): raise AppError("Invalid consumable status")
    if resource=="quotations":
        merged={**before,**data}; subtotal,tax,total=calculate_quote(merged); data.update({"subtotal":subtotal,"total":total})
        if int(merged["duration_days"])<1: raise AppError("Duration must be at least one day")
    if resource=="invoices" and data.get("payment_status")=="Paid": data["paid_at"]=now(); allowed[resource].add("paid_at")
    user_changes={k:data[k] for k in ("display_name","email") if resource=="operators" and k in data}
    changes={k:v for k,v in data.items() if k in allowed[resource]}
    if not changes and not user_changes: raise AppError("No editable fields supplied")
    for key in ("custom_fields","skills","line_items"):
        if key in changes: changes[key]=json.dumps(changes[key])
    if changes:
        changes["updated_at"]=now(); assignments=",".join(f"{k}=?" for k in changes)
        conn.execute(f"UPDATE {table} SET {assignments} WHERE id=?",(*changes.values(),resource_id))
    if user_changes:
        user_changes["updated_at"]=now(); assignments=",".join(f"{k}=?" for k in user_changes)
        conn.execute(f"UPDATE users SET {assignments} WHERE id=(SELECT user_id FROM operators WHERE id=?)",(*user_changes.values(),resource_id))
    after=row_dict(conn.execute(f"SELECT * FROM {table} WHERE id=?",(resource_id,)).fetchone())
    kind=resource[:-1] if resource.endswith("s") else resource
    if resource in ("devices","consumables") and before["status"]!=after["status"]:
        conn.execute("INSERT INTO inventory_history(resource_type,resource_id,from_status,to_status,from_location_id,to_location_id,notes,changed_by,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (kind,resource_id,before["status"],after["status"],before["location_id"],after["location_id"],data.get("notes") or "Administrative status update",actor,now()))
    audit(conn,actor,"update",kind,resource_id,before,after)
    return after  # type: ignore[return-value]


def create_quote(conn: sqlite3.Connection, data: dict[str, Any], actor: int) -> dict[str, Any]:
    require(data, "customer_id", "treatment", "duration_days", "subtotal")
    if int(data["duration_days"]) < 1: raise AppError("Duration must be at least one day")
    if not conn.execute("SELECT 1 FROM customers WHERE id=?", (data["customer_id"],)).fetchone(): raise AppError("Customer not found", 404)
    subtotal, tax, total = calculate_quote(data)
    quote_number = data.get("quote_number") or f"QUO-{datetime.now().strftime('%Y%m')}-{conn.execute('SELECT COUNT(*)+1 FROM quotations').fetchone()[0]:04d}"
    stamp = now()
    try:
        cur = conn.execute("""INSERT INTO quotations(quote_number,customer_id,treatment,description,duration_days,treatment_start,subtotal,tax_rate,discount,total,cost_estimate,status,payment_status,line_items,created_by,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (quote_number, int(data["customer_id"]), data["treatment"], data.get("description"), int(data["duration_days"]),
            data.get("treatment_start"), subtotal, float(data.get("tax_rate",0)), float(data.get("discount",0)), total,
            float(data.get("cost_estimate",0)), data.get("status","Draft"), data.get("payment_status","Unpaid"), json.dumps(data.get("line_items",[])), actor, stamp, stamp))
    except sqlite3.IntegrityError as exc: raise AppError("Quote number already exists", 409, "duplicate") from exc
    item = row_dict(conn.execute("SELECT * FROM quotations WHERE id=?", (cur.lastrowid,)).fetchone())
    audit(conn, actor, "create", "quotation", cur.lastrowid, after=item)
    return item  # type: ignore[return-value]


def approve_quote(conn: sqlite3.Connection, quote_id: int, actor: int) -> dict[str, Any]:
    before = row_dict(conn.execute("SELECT * FROM quotations WHERE id=?", (quote_id,)).fetchone())
    if not before: raise AppError("Quotation not found", 404)
    if before["status"] not in ("Draft", "Sent"): raise AppError("Only Draft or Sent quotations may be approved", 409)
    conn.execute("UPDATE quotations SET status='Approved',approved_at=?,updated_at=? WHERE id=?", (now(), now(), quote_id))
    after = row_dict(conn.execute("SELECT * FROM quotations WHERE id=?", (quote_id,)).fetchone())
    audit(conn, actor, "approve", "quotation", quote_id, before, after)
    return after  # type: ignore[return-value]


def _distance_score(a: sqlite3.Row | None, b: sqlite3.Row | None) -> float:
    if not a or not b: return 40
    if a["latitude"] is not None and b["latitude"] is not None:
        lat1, lon1, lat2, lon2 = map(math.radians, [a["latitude"], a["longitude"], b["latitude"], b["longitude"]])
        h = math.sin((lat2-lat1)/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin((lon2-lon1)/2)**2
        return min(100, 6371 * 2 * math.asin(math.sqrt(h)) / 10)
    if a["district"].lower() == b["district"].lower(): return 0
    if a["state"].lower() == b["state"].lower(): return 15
    if a["country"].lower() == b["country"].lower(): return 35
    return 75


def recommendations(conn: sqlite3.Connection, start_at: str, end_at: str, location_id: int | None, category: str | None = None) -> dict[str, Any]:
    start_at, end_at = iso(start_at, "start_at"), iso(end_at, "end_at")
    target = conn.execute("SELECT * FROM locations WHERE id=?", (location_id,)).fetchone() if location_id else None
    operators = []
    for op in conn.execute("""SELECT o.*,u.display_name,l.district,l.state,l.country,l.latitude,l.longitude,
        (SELECT COUNT(*) FROM schedules s WHERE s.operator_id=o.id AND s.status NOT IN ('Completed','Cancelled') AND s.starts_at < ? AND s.ends_at > ?) conflicts,
        (SELECT COUNT(*) FROM jobs j WHERE j.operator_id=o.id AND j.status NOT IN ('Completed','Cancelled')) workload
        FROM operators o JOIN users u ON u.id=o.user_id LEFT JOIN locations l ON l.id=o.location_id WHERE o.availability_status='Available'""", (end_at,start_at)):
        if op["conflicts"]: continue
        loc = conn.execute("SELECT * FROM locations WHERE id=?", (op["location_id"],)).fetchone() if op["location_id"] else None
        score = round(100 - _distance_score(loc,target) - op["workload"]*12, 1)
        operators.append({**row_dict(op), "score": max(0,score), "reason": f"{op['workload']} active jobs; location match considered"})
    operators.sort(key=lambda x: x["score"], reverse=True)
    query = """SELECT d.*,l.district,l.state,l.country,l.latitude,l.longitude FROM devices d LEFT JOIN locations l ON l.id=d.location_id
        WHERE d.status NOT IN ('Broken','Maintenance','Lost','Retired')"""
    args: list[Any] = []
    if category: query += " AND d.category=?"; args.append(category)
    devices = []
    for dev in conn.execute(query,args):
        conflict = conn.execute("""SELECT allocated_until FROM allocations WHERE resource_type='device' AND resource_id=?
            AND status NOT IN ('Returned','Cancelled') AND allocated_from < ? AND allocated_until > ? ORDER BY allocated_until DESC LIMIT 1""", (dev["id"],end_at,start_at)).fetchone()
        loc = conn.execute("SELECT * FROM locations WHERE id=?",(dev["location_id"],)).fetchone() if dev["location_id"] else None
        if conflict:
            devices.append({**row_dict(dev), "score": 0, "available": False, "available_from": conflict[0], "reason": "Overlapping allocation"})
        else:
            score = round(100 - _distance_score(loc,target),1)
            devices.append({**row_dict(dev), "score": max(0,score), "available": True, "reason": "Available for full treatment window"})
    devices.sort(key=lambda x:(x["available"],x["score"]), reverse=True)
    return {"operators":operators,"devices":devices,"window":{"start_at":start_at,"end_at":end_at}}


def create_job(conn: sqlite3.Connection, quote_id: int, data: dict[str, Any], actor: int) -> dict[str, Any]:
    quote = row_dict(conn.execute("SELECT * FROM quotations WHERE id=?", (quote_id,)).fetchone())
    if not quote: raise AppError("Quotation not found",404)
    if quote["status"] != "Approved": raise AppError("Quotation must be approved before conversion",409)
    if conn.execute("SELECT 1 FROM jobs WHERE quotation_id=?",(quote_id,)).fetchone(): raise AppError("Quotation already converted",409)
    customer = conn.execute("SELECT * FROM customers WHERE id=?",(quote["customer_id"],)).fetchone()
    start_at = iso(data.get("start_at") or quote.get("treatment_start") or now(),"start_at")
    end_at = (datetime.fromisoformat(start_at)+timedelta(days=int(quote["duration_days"]))).isoformat()
    operator_id = data.get("operator_id")
    location_id = data.get("service_location_id") or customer["service_location_id"]
    if operator_id:
        conflict = conn.execute("SELECT 1 FROM schedules WHERE operator_id=? AND status NOT IN ('Completed','Cancelled') AND starts_at < ? AND ends_at > ?",(operator_id,end_at,start_at)).fetchone()
        if conflict and not data.get("override_reason"): raise AppError("Operator has a conflicting schedule",409,"scheduling_conflict")
    job_number = data.get("job_number") or f"JOB-{datetime.now().strftime('%Y%m')}-{conn.execute('SELECT COUNT(*)+1 FROM jobs').fetchone()[0]:04d}"
    stamp=now()
    cur=conn.execute("""INSERT INTO jobs(job_number,quotation_id,customer_id,operator_id,treatment,status,start_at,end_at,service_location_id,priority,revenue,estimated_cost,override_reason,created_by,created_at,updated_at)
        VALUES (?,?,?,?,?,'Scheduled',?,?,?,?,?,?,?,?,?,?)""",(job_number,quote_id,quote["customer_id"],operator_id,quote["treatment"],start_at,end_at,location_id,
        data.get("priority","Normal"),quote["total"],quote["cost_estimate"],data.get("override_reason"),actor,stamp,stamp))
    job_id=cur.lastrowid
    conn.execute("INSERT INTO schedules(job_id,operator_id,starts_at,ends_at,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",(job_id,operator_id,start_at,end_at,"Scheduled",stamp,stamp))
    inv_no=f"INV-{datetime.now().strftime('%Y%m')}-{job_id:04d}"
    conn.execute("INSERT INTO invoices(invoice_number,quotation_id,job_id,customer_id,amount,tax,discount,payment_status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (inv_no,quote_id,job_id,quote["customer_id"],quote["total"],round((quote["subtotal"]-quote["discount"])*quote["tax_rate"]/100,2),quote["discount"],quote["payment_status"],stamp,stamp))
    if operator_id:
        uid=conn.execute("SELECT user_id FROM operators WHERE id=?",(operator_id,)).fetchone()
        if uid: conn.execute("INSERT INTO notifications(user_id,kind,title,message,job_id,created_at) VALUES (?,?,?,?,?,?)",(uid[0],"assignment","New job assigned",f"{job_number}: {quote['treatment']}",job_id,stamp))
    item=row_dict(conn.execute("SELECT * FROM jobs WHERE id=?",(job_id,)).fetchone())
    audit(conn,actor,"convert","job",job_id,after=item)
    return item  # type: ignore[return-value]


def allocate(conn: sqlite3.Connection, job_id: int, data: dict[str, Any], actor: int) -> dict[str, Any]:
    require(data,"resource_type","resource_id")
    kind=data["resource_type"]
    if kind not in ("device","consumable"): raise AppError("resource_type must be device or consumable")
    job=conn.execute("SELECT * FROM jobs WHERE id=?",(job_id,)).fetchone()
    if not job: raise AppError("Job not found",404)
    if job["status"] in ("Completed","Cancelled"): raise AppError("Cannot allocate to a closed job",409)
    table="devices" if kind=="device" else "consumables"
    item=conn.execute(f"SELECT * FROM {table} WHERE id=?",(int(data["resource_id"]),)).fetchone()
    if not item: raise AppError(f"{kind.title()} not found",404)
    unavailable = item["status"] in ({"Broken","Maintenance","Lost","Retired"} if kind=="device" else {"Consumed","Damaged","Expired","Lost"})
    if unavailable and not data.get("override_reason"): raise AppError(f"{kind.title()} is {item['status']} and cannot be allocated",409,"unavailable")
    conflict=conn.execute("""SELECT a.id,j.job_number,a.allocated_until FROM allocations a JOIN jobs j ON j.id=a.job_id
        WHERE a.resource_type=? AND a.resource_id=? AND a.status NOT IN ('Returned','Cancelled','Consumed')
        AND a.allocated_from < ? AND a.allocated_until > ?""",(kind,item["id"],job["end_at"],job["start_at"])).fetchone()
    if conflict and not data.get("override_reason"): raise AppError(f"Resource conflicts with {conflict['job_number']} until {conflict['allocated_until']}",409,"allocation_conflict")
    quantity=float(data.get("quantity",1))
    if kind=="consumable" and quantity>item["quantity"]: raise AppError("Insufficient consumable quantity",409,"insufficient_stock")
    stamp=now()
    cur=conn.execute("INSERT INTO allocations(job_id,resource_type,resource_id,quantity,allocated_from,allocated_until,status,override_reason,created_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (job_id,kind,item["id"],quantity,job["start_at"],job["end_at"],"Allocated",data.get("override_reason"),actor,stamp,stamp))
    conn.execute(f"UPDATE {table} SET status='Allocated',current_job_id=?,current_operator_id=?,updated_at=? WHERE id=?",(job_id,job["operator_id"],stamp,item["id"]))
    conn.execute("INSERT INTO inventory_history(resource_type,resource_id,job_id,from_status,to_status,from_location_id,to_location_id,operator_id,notes,changed_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (kind,item["id"],job_id,item["status"],"Allocated",item["location_id"],job["service_location_id"],job["operator_id"],data.get("override_reason") or "Allocated to job",actor,stamp))
    conn.execute("UPDATE jobs SET status=CASE WHEN status='Scheduled' THEN 'Allocated' ELSE status END,updated_at=? WHERE id=?",(stamp,job_id))
    result=row_dict(conn.execute("SELECT * FROM allocations WHERE id=?",(cur.lastrowid,)).fetchone())
    audit(conn,actor,"allocate",kind,item["id"],after=result)
    return result  # type: ignore[return-value]


def job_detail(conn: sqlite3.Connection, job_id: int, user: dict[str,Any]) -> dict[str,Any]:
    job=row_dict(conn.execute("""SELECT j.*,c.name customer_name,u.display_name operator_name,l.address,l.district,l.state,l.country
        FROM jobs j JOIN customers c ON c.id=j.customer_id LEFT JOIN operators o ON o.id=j.operator_id LEFT JOIN users u ON u.id=o.user_id
        LEFT JOIN locations l ON l.id=j.service_location_id WHERE j.id=?""",(job_id,)).fetchone())
    if not job: raise AppError("Job not found",404)
    if user["role"]=="Operator":
        op=conn.execute("SELECT id FROM operators WHERE user_id=?",(user["id"],)).fetchone()
        if not op or job["operator_id"]!=op[0]: raise AppError("Not assigned to this job",403)
    job["allocations"]=rows_dict(conn.execute("""SELECT a.*,CASE WHEN a.resource_type='device' THEN d.serial_number ELSE c.serial_number END serial_number,
        CASE WHEN a.resource_type='device' THEN d.model ELSE c.name END resource_name FROM allocations a LEFT JOIN devices d ON a.resource_type='device' AND d.id=a.resource_id
        LEFT JOIN consumables c ON a.resource_type='consumable' AND c.id=a.resource_id WHERE a.job_id=?""",(job_id,)).fetchall())
    job["shipments"]=rows_dict(conn.execute("SELECT * FROM shipments WHERE job_id=?",(job_id,)).fetchall())
    job["collections"]=rows_dict(conn.execute("SELECT * FROM collections WHERE job_id=?",(job_id,)).fetchall())
    job["proofs"]=rows_dict(conn.execute("SELECT id,kind,original_name,mime_type,captured_at,latitude,longitude,created_at FROM proofs WHERE job_id=?",(job_id,)).fetchall())
    return job


def transition_job(conn: sqlite3.Connection, job_id: int, new_status: str, data: dict[str,Any], user: dict[str,Any]) -> dict[str,Any]:
    job=conn.execute("SELECT * FROM jobs WHERE id=?",(job_id,)).fetchone()
    if not job: raise AppError("Job not found",404)
    if new_status not in JOB_TRANSITIONS.get(job["status"],set()): raise AppError(f"Invalid transition from {job['status']} to {new_status}",409,"invalid_transition")
    if user["role"]=="Operator":
        op=conn.execute("SELECT id FROM operators WHERE user_id=?",(user["id"],)).fetchone()
        if not op or job["operator_id"]!=op[0]: raise AppError("Not assigned to this job",403)
    stamp=now(); allocations=conn.execute("SELECT * FROM allocations WHERE job_id=? AND status NOT IN ('Returned','Cancelled')",(job_id,)).fetchall()
    status_map={"Shipped":"Shipped","Received":"Received","In Treatment":"In Use"}
    if new_status in status_map:
        target=status_map[new_status]
        for a in allocations:
            table="devices" if a["resource_type"]=="device" else "consumables"
            old=conn.execute(f"SELECT status,location_id FROM {table} WHERE id=?",(a["resource_id"],)).fetchone()
            conn.execute(f"UPDATE {table} SET status=?,location_id=COALESCE(?,location_id),updated_at=? WHERE id=?",(target,job["service_location_id"] if new_status=="Received" else None,stamp,a["resource_id"]))
            conn.execute("UPDATE allocations SET status=?,updated_at=? WHERE id=?",(target,stamp,a["id"]))
            conn.execute("INSERT INTO inventory_history(resource_type,resource_id,job_id,from_status,to_status,from_location_id,to_location_id,operator_id,notes,changed_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (a["resource_type"],a["resource_id"],job_id,old["status"],target,old["location_id"],job["service_location_id"],job["operator_id"],f"Job moved to {new_status}",user["id"],stamp))
    if new_status=="Shipped":
        conn.execute("INSERT INTO shipments(job_id,tracking_number,carrier,from_location_id,to_location_id,status,shipped_at,created_at,updated_at) VALUES (?,?,?,?,?,'Shipped',?,?,?)",
            (job_id,data.get("tracking_number"),data.get("carrier"),data.get("from_location_id"),job["service_location_id"],stamp,stamp,stamp))
    elif new_status=="Received": conn.execute("UPDATE shipments SET status='Received',received_at=?,updated_at=? WHERE job_id=? AND status='Shipped'",(stamp,stamp,job_id))
    elif new_status=="Awaiting Collection":
        conn.execute("INSERT INTO collections(job_id,assigned_operator_id,location_id,scheduled_at,status,notes,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)",
            (job_id,job["operator_id"],job["service_location_id"],data.get("scheduled_at") or stamp,"Pending",data.get("notes"),stamp,stamp))
        if job["operator_id"]:
            uid=conn.execute("SELECT user_id FROM operators WHERE id=?",(job["operator_id"],)).fetchone()[0]
            serials=[conn.execute(f"SELECT serial_number FROM {'devices' if a['resource_type']=='device' else 'consumables'} WHERE id=?",(a["resource_id"],)).fetchone()[0] for a in allocations]
            conn.execute("INSERT INTO notifications(user_id,kind,title,message,job_id,created_at) VALUES (?,?,?,?,?,?)",(uid,"collection","Collection due",f"{job['job_number']}: collect {', '.join(str(s) for s in serials)}",job_id,stamp))
    elif new_status=="Collected":
        conn.execute("UPDATE collections SET status='Collected',collected_at=?,updated_at=? WHERE job_id=? AND status='Pending'",(stamp,stamp,job_id))
    elif new_status=="Completed":
        for a in allocations:
            table="devices" if a["resource_type"]=="device" else "consumables"
            quantity_col="NULL AS quantity" if a["resource_type"]=="device" else "quantity"
            old=conn.execute(f"SELECT status,location_id,{quantity_col} FROM {table} WHERE id=?",(a["resource_id"],)).fetchone()
            target="Available" if a["resource_type"]=="device" else ("Consumed" if data.get("consume",True) else "Returned")
            if a["resource_type"]=="consumable" and target=="Consumed":
                remaining=max(0,float(old["quantity"])-float(a["quantity"])); final_status="Consumed" if remaining==0 else "Available"
                conn.execute("UPDATE consumables SET quantity=?,status=?,current_job_id=NULL,current_operator_id=NULL,updated_at=? WHERE id=?",(remaining,final_status,stamp,a["resource_id"])); target=final_status
            else: conn.execute(f"UPDATE {table} SET status=?,current_job_id=NULL,current_operator_id=NULL,updated_at=? WHERE id=?",(target,stamp,a["resource_id"]))
            conn.execute("UPDATE allocations SET status=?,returned_at=?,updated_at=? WHERE id=?",("Consumed" if a["resource_type"]=="consumable" and data.get("consume",True) else "Returned",stamp,stamp,a["id"]))
            conn.execute("INSERT INTO inventory_history(resource_type,resource_id,job_id,from_status,to_status,from_location_id,to_location_id,operator_id,notes,changed_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (a["resource_type"],a["resource_id"],job_id,old["status"],target,old["location_id"],old["location_id"],job["operator_id"],"Job completed and inventory reconciled",user["id"],stamp))
        conn.execute("UPDATE schedules SET status='Completed',updated_at=? WHERE job_id=?",(stamp,job_id))
    elif new_status=="Cancelled":
        conn.execute("UPDATE allocations SET status='Cancelled',updated_at=? WHERE job_id=?",(stamp,job_id)); conn.execute("UPDATE schedules SET status='Cancelled',updated_at=? WHERE job_id=?",(stamp,job_id))
    permitted_actual_cost=data.get("actual_cost") if user["role"]=="Admin" else None
    conn.execute("UPDATE jobs SET status=?,completed_at=CASE WHEN ?='Completed' THEN ? ELSE completed_at END,cancelled_at=CASE WHEN ?='Cancelled' THEN ? ELSE cancelled_at END,actual_cost=COALESCE(?,actual_cost),updated_at=? WHERE id=?",
        (new_status,new_status,stamp,new_status,stamp,permitted_actual_cost,stamp,job_id))
    audit(conn,user["id"],"transition","job",job_id,{"status":job["status"]},{"status":new_status})
    return job_detail(conn,job_id,user)


def dashboard(conn: sqlite3.Connection, user: dict[str,Any]) -> dict[str,Any]:
    if user["role"]=="Operator":
        op=conn.execute("SELECT id FROM operators WHERE user_id=?",(user["id"],)).fetchone(); oid=op[0] if op else -1
        counts={r["status"]:r["n"] for r in conn.execute("SELECT status,COUNT(*) n FROM jobs WHERE operator_id=? GROUP BY status",(oid,))}
        return {"role":"Operator","kpis":{"assigned_jobs":sum(counts.values()),"active_jobs":sum(v for k,v in counts.items() if k not in ('Completed','Cancelled')),
            "upcoming":conn.execute("SELECT COUNT(*) FROM jobs WHERE operator_id=? AND start_at>=? AND status NOT IN ('Completed','Cancelled')",(oid,now())).fetchone()[0],
            "collection_tasks":conn.execute("SELECT COUNT(*) FROM collections WHERE assigned_operator_id=? AND status='Pending'",(oid,)).fetchone()[0]},
            "jobs":list_resources(conn,"jobs",user,{}),"notifications":list_resources(conn,"notifications",user,{})[:10]}
    active="status NOT IN ('Completed','Cancelled')"
    kpis={
        "revenue":conn.execute("SELECT COALESCE(SUM(revenue),0) FROM jobs WHERE status='Completed'").fetchone()[0],
        "active_jobs":conn.execute(f"SELECT COUNT(*) FROM jobs WHERE {active}").fetchone()[0],
        "completed_jobs":conn.execute("SELECT COUNT(*) FROM jobs WHERE status='Completed'").fetchone()[0],
        "available_devices":conn.execute("SELECT COUNT(*) FROM devices WHERE status='Available'").fetchone()[0],
        "device_issues":conn.execute("SELECT COUNT(*) FROM devices WHERE status IN ('Broken','Maintenance','Lost')").fetchone()[0],
        "low_stock":conn.execute("SELECT COUNT(*) FROM consumables WHERE quantity<=5 AND status NOT IN ('Consumed','Expired')").fetchone()[0],
        "pending_collections":conn.execute("SELECT COUNT(*) FROM collections WHERE status='Pending'").fetchone()[0],
        "upcoming_treatments":conn.execute("SELECT COUNT(*) FROM jobs WHERE start_at>=? AND status NOT IN ('Completed','Cancelled')",(now(),)).fetchone()[0],
    }
    alerts=[]
    for r in conn.execute("SELECT serial_number,maintenance_due_at FROM devices WHERE maintenance_due_at IS NOT NULL AND maintenance_due_at<=date('now','+30 day') AND status!='Retired'"):
        alerts.append({"kind":"maintenance","message":f"{r['serial_number']} maintenance due {r['maintenance_due_at']}"})
    for r in conn.execute("SELECT name,quantity,unit FROM consumables WHERE quantity<=5 AND status NOT IN ('Consumed','Expired')"):
        alerts.append({"kind":"stock","message":f"Low stock: {r['name']} ({r['quantity']} {r['unit']})"})
    return {"role":"Admin","kpis":kpis,"job_status":rows_dict(conn.execute("SELECT status,COUNT(*) count FROM jobs GROUP BY status").fetchall()),
        "device_status":rows_dict(conn.execute("SELECT status,COUNT(*) count FROM devices GROUP BY status").fetchall()),
        "operator_workload":rows_dict(conn.execute("""SELECT u.display_name operator,COUNT(j.id) active_jobs FROM operators o JOIN users u ON u.id=o.user_id LEFT JOIN jobs j ON j.operator_id=o.id AND j.status NOT IN ('Completed','Cancelled') GROUP BY o.id""").fetchall()),
        "upcoming":rows_dict(conn.execute("SELECT id,job_number,treatment,start_at,status FROM jobs WHERE status NOT IN ('Completed','Cancelled') ORDER BY start_at LIMIT 8").fetchall()),"alerts":alerts}


def analytics(conn: sqlite3.Connection, params: dict[str,str]) -> dict[str,Any]:
    clauses=["1=1"]; values=[]
    mapping={"status":"j.status","operator":"j.operator_id","customer":"j.customer_id","treatment":"j.treatment","location":"j.service_location_id"}
    if params.get("date_from"): clauses.append("j.start_at>=?"); values.append(params["date_from"])
    if params.get("date_to"): clauses.append("j.start_at<=?"); values.append(params["date_to"]+"T23:59:59+00:00")
    for key,col in mapping.items():
        if params.get(key): clauses.append(f"{col}=?"); values.append(params[key])
    for key,kind in (("device","device"),("consumable","consumable")):
        if params.get(key): clauses.append("EXISTS (SELECT 1 FROM allocations ax WHERE ax.job_id=j.id AND ax.resource_type=? AND ax.resource_id=?)"); values.extend([kind,params[key]])
    where=" AND ".join(clauses)
    totals=conn.execute(f"SELECT COALESCE(SUM(j.revenue),0) revenue,COALESCE(SUM(CASE WHEN j.actual_cost>0 THEN j.actual_cost ELSE j.estimated_cost END),0) cost,COUNT(*) jobs,SUM(j.status='Completed') completed,SUM(j.status='Cancelled') cancelled,SUM(j.status NOT IN ('Completed','Cancelled')) active,SUM(j.status NOT IN ('Completed','Cancelled') AND julianday(j.end_at)<julianday('now')) delayed,AVG(julianday(j.end_at)-julianday(j.start_at)) avg_duration FROM jobs j WHERE {where}",values).fetchone()
    revenue=float(totals["revenue"]); cost=float(totals["cost"]); profit=revenue-cost
    series=rows_dict(conn.execute(f"SELECT substr(j.start_at,1,7) period,SUM(j.revenue) revenue,SUM(CASE WHEN j.actual_cost>0 THEN j.actual_cost ELSE j.estimated_cost END) cost,COUNT(*) jobs FROM jobs j WHERE {where} GROUP BY period ORDER BY period",values).fetchall())
    def breakdown(col:str,label:str): return rows_dict(conn.execute(f"SELECT {col} label,SUM(j.revenue) revenue,SUM(j.revenue-CASE WHEN j.actual_cost>0 THEN j.actual_cost ELSE j.estimated_cost END) profit,COUNT(*) jobs,SUM(j.status='Completed') completed FROM jobs j LEFT JOIN customers c ON c.id=j.customer_id LEFT JOIN operators o ON o.id=j.operator_id LEFT JOIN users u ON u.id=o.user_id LEFT JOIN devices d ON d.current_job_id=j.id LEFT JOIN locations l ON l.id=j.service_location_id WHERE {where} GROUP BY {col} ORDER BY revenue DESC",values).fetchall())
    completed_clause=where+" AND j.status='Completed'"
    turnaround=conn.execute(f"SELECT AVG((julianday(c.collected_at)-julianday(j.end_at))*24) hours FROM jobs j LEFT JOIN collections c ON c.job_id=j.id WHERE {completed_clause}",values).fetchone()[0]
    devices=rows_dict(conn.execute("""SELECT d.id,d.serial_number,d.model,
        (SELECT COUNT(DISTINCT a.job_id) FROM allocations a WHERE a.resource_type='device' AND a.resource_id=d.id) jobs,
        COALESCE((SELECT SUM(j.revenue) FROM allocations a JOIN jobs j ON j.id=a.job_id WHERE a.resource_type='device' AND a.resource_id=d.id),0) revenue,
        ROUND(COALESCE((SELECT SUM(julianday(a.allocated_until)-julianday(a.allocated_from)) FROM allocations a WHERE a.resource_type='device' AND a.resource_id=d.id),0),1) utilized_days,
        ROUND(MIN(100,COALESCE((SELECT SUM(julianday(a.allocated_until)-julianday(a.allocated_from)) FROM allocations a WHERE a.resource_type='device' AND a.resource_id=d.id),0)/365*100),1) utilization_pct,
        COALESCE((SELECT SUM(j.revenue-CASE WHEN j.actual_cost>0 THEN j.actual_cost ELSE j.estimated_cost END) FROM allocations a JOIN jobs j ON j.id=a.job_id WHERE a.resource_type='device' AND a.resource_id=d.id),0) profit,
        ROUND(COALESCE((SELECT SUM(julianday(COALESCE(m.completed_at,CURRENT_TIMESTAMP))-julianday(m.started_at)) FROM maintenance m WHERE m.device_id=d.id),0),1) downtime_days
        FROM devices d ORDER BY revenue DESC""").fetchall())
    consumables=rows_dict(conn.execute("""SELECT c.name,c.sku,SUM(CASE WHEN a.status='Consumed' THEN a.quantity ELSE 0 END) used,
        SUM(CASE WHEN a.status='Consumed' THEN a.quantity*c.unit_cost ELSE 0 END) cost,
        SUM(CASE WHEN a.status='Consumed' THEN j.revenue ELSE 0 END) revenue,
        SUM(CASE WHEN a.status='Consumed' THEN j.revenue-a.quantity*c.unit_cost ELSE 0 END) profit
        FROM consumables c LEFT JOIN allocations a ON a.resource_type='consumable' AND a.resource_id=c.id LEFT JOIN jobs j ON j.id=a.job_id GROUP BY c.id ORDER BY cost DESC""").fetchall())
    return {"kpis":{"revenue":revenue,"cost":cost,"gross_profit":profit,"margin":round(profit/revenue*100,1) if revenue else 0,"jobs":totals["jobs"],"active":totals["active"],"completed":totals["completed"],"delayed":totals["delayed"],"cancelled":totals["cancelled"],"average_treatment_days":round(totals["avg_duration"] or 0,1),"collection_turnaround_hours":round(turnaround or 0,1)},
        "trend":series,"by_customer":breakdown("c.name","customer"),"by_treatment":breakdown("j.treatment","treatment"),"by_operator":breakdown("u.display_name","operator"),"by_location":breakdown("l.state","location"),"devices":devices,"consumables":consumables}


def _xlsx_rows(content: bytes) -> list[dict[str, str]]:
    """Read the first worksheet from a basic XLSX using only the standard library."""
    ns={"m":"http://schemas.openxmlformats.org/spreadsheetml/2006/main","r":"http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
    try:
        with zipfile.ZipFile(io.BytesIO(content)) as book:
            shared=[]
            if "xl/sharedStrings.xml" in book.namelist():
                root=ET.fromstring(book.read("xl/sharedStrings.xml"))
                shared=["".join(t.text or "" for t in si.findall(".//m:t",ns)) for si in root.findall("m:si",ns)]
            sheet=ET.fromstring(book.read("xl/worksheets/sheet1.xml"))
            matrix=[]
            for row in sheet.findall(".//m:sheetData/m:row",ns):
                values={}
                for cell in row.findall("m:c",ns):
                    ref=cell.attrib.get("r",""); letters="".join(ch for ch in ref if ch.isalpha()); col=0
                    for ch in letters: col=col*26+ord(ch.upper())-64
                    node=cell.find("m:v",ns); value=node.text if node is not None and node.text is not None else ""
                    if cell.attrib.get("t")=="s" and value: value=shared[int(value)]
                    elif cell.attrib.get("t")=="inlineStr": value="".join(t.text or "" for t in cell.findall(".//m:t",ns))
                    values[col-1]=value
                if values: matrix.append([values.get(i,"") for i in range(max(values)+1)])
            if not matrix: return []
            headers=[str(x).strip() for x in matrix[0]]
            return [{headers[i]:str(row[i]).strip() if i<len(row) else "" for i in range(len(headers)) if headers[i]} for row in matrix[1:]]
    except (zipfile.BadZipFile,KeyError,ET.ParseError,ValueError) as exc:
        raise AppError("XLSX file is invalid or unsupported") from exc


def import_csv(conn: sqlite3.Connection, entity: str, filename: str, content: bytes, actor: int) -> dict[str,Any]:
    if entity not in ("devices","consumables","customers"): raise AppError("Import supports devices, consumables, and customers")
    if filename.lower().endswith(".xlsx"):
        rows=_xlsx_rows(content)
    else:
        try: rows=list(csv.DictReader(io.StringIO(content.decode("utf-8-sig"))))
        except UnicodeDecodeError as exc: raise AppError("CSV must be UTF-8 encoded") from exc
    stamp=now(); cur=conn.execute("INSERT INTO import_batches(entity_type,filename,status,rows_total,uploaded_by,created_at) VALUES (?,?,?,?,?,?)",(entity,filename,"Processing",len(rows),actor,stamp)); bid=cur.lastrowid
    imported=0; errors=[]
    for number,data in enumerate(rows,2):
        try:
            if entity=="devices": create_inventory(conn,"device",data,actor)
            elif entity=="consumables": create_inventory(conn,"consumable",data,actor)
            else: create_customer(conn,data,actor)
            imported+=1
        except (AppError,ValueError,sqlite3.Error) as exc: errors.append({"row":number,"error":str(exc),"data":data})
    conn.execute("UPDATE import_batches SET status=?,rows_imported=?,rows_failed=?,error_report=?,completed_at=? WHERE id=?",("Completed with errors" if errors else "Completed",imported,len(errors),json.dumps(errors),now(),bid))
    audit(conn,actor,"import",entity,bid,after={"total":len(rows),"imported":imported,"failed":len(errors)})
    return {"id":bid,"status":"Completed with errors" if errors else "Completed","rows_total":len(rows),"rows_imported":imported,"rows_failed":len(errors),"errors":errors}
