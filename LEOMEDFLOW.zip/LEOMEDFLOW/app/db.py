from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from . import config


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def connect(path: Path | str | None = None) -> sqlite3.Connection:
    config.ensure_directories()
    conn = sqlite3.connect(str(path or config.DATABASE), timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn


@contextmanager
def transaction(path: Path | str | None = None) -> Iterator[sqlite3.Connection]:
    conn = connect(path)
    try:
        conn.execute("BEGIN")
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def row_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    out = dict(row)
    for key in ("permissions", "skills", "custom_fields", "line_items", "options", "metadata", "error_report"):
        if key in out and isinstance(out[key], str):
            try:
                out[key] = json.loads(out[key])
            except json.JSONDecodeError:
                pass
    return out


def rows_dict(rows: list[sqlite3.Row]) -> list[dict[str, Any]]:
    return [row_dict(r) for r in rows]  # type: ignore[misc]


def migrate(path: Path | str | None = None) -> list[str]:
    db_path = path or config.DATABASE
    applied: list[str] = []
    with connect(db_path) as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
        existing = {r[0] for r in conn.execute("SELECT version FROM schema_migrations")}
        for migration in sorted((config.ROOT / "migrations").glob("[0-9]*.sql")):
            if migration.name.endswith(".down.sql") or migration.stem in existing:
                continue
            conn.executescript(migration.read_text())
            conn.execute("INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)", (migration.stem, now()))
            applied.append(migration.stem)
    return applied


def rollback(path: Path | str | None = None, version: str = "001_initial") -> None:
    script = config.ROOT / "migrations" / f"{version}.down.sql"
    if not script.exists():
        raise ValueError(f"No rollback script for {version}")
    with connect(path or config.DATABASE) as conn:
        conn.executescript(script.read_text())


def audit(conn: sqlite3.Connection, actor: int | None, action: str, entity: str,
          entity_id: Any = None, before: Any = None, after: Any = None,
          ip: str | None = None, user_agent: str | None = None) -> None:
    conn.execute(
        "INSERT INTO audit_logs(actor_user_id,action,entity_type,entity_id,before_data,after_data,ip_address,user_agent,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
        (actor, action, entity, str(entity_id) if entity_id is not None else None,
         json.dumps(before, default=str) if before is not None else None,
         json.dumps(after, default=str) if after is not None else None, ip, user_agent, now()),
    )
