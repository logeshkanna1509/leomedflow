from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
INSTANCE = Path(os.getenv("LEOMEDFLOW_INSTANCE", ROOT / "instance"))
DATABASE = Path(os.getenv("LEOMEDFLOW_DATABASE", INSTANCE / "leomedflow.db"))
UPLOAD_DIR = Path(os.getenv("LEOMEDFLOW_UPLOAD_DIR", ROOT / "uploads"))
HOST = os.getenv("LEOMEDFLOW_HOST", "127.0.0.1")
PORT = int(os.getenv("LEOMEDFLOW_PORT", "8080"))
SECRET_KEY = os.getenv("LEOMEDFLOW_SECRET_KEY", "development-only-change-me")
ENVIRONMENT = os.getenv("LEOMEDFLOW_ENV", "development")
SESSION_HOURS = int(os.getenv("LEOMEDFLOW_SESSION_HOURS", "12"))
MAX_UPLOAD_BYTES = int(os.getenv("LEOMEDFLOW_MAX_UPLOAD_BYTES", str(10 * 1024 * 1024)))
ALLOWED_EXTENSIONS = {"pdf", "png", "jpg", "jpeg", "webp", "csv", "xlsx"}


def ensure_directories() -> None:
    # DATABASE may be redirected to persistent service storage. Creating the
    # source-tree instance directory in that case breaks read-only deployments.
    DATABASE.parent.mkdir(parents=True, exist_ok=True)
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
