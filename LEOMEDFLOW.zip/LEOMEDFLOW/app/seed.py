from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from .db import migrate, now, transaction
from .security import hash_password


def seed(database=None) -> None:
    migrate(database)
    with transaction(database) as c:
        if c.execute("SELECT 1 FROM users WHERE username='admin'").fetchone():
            print("Demo data already present; seed skipped")
            return
        stamp=now(); today=datetime.now(timezone.utc).replace(hour=9,minute=0,second=0,microsecond=0)
        admin_role=c.execute("INSERT INTO roles(name,permissions) VALUES ('Admin','[\"*\"]')").lastrowid
        operator_role=c.execute("INSERT INTO roles(name,permissions) VALUES ('Operator','[\"jobs:assigned\",\"inventory:assigned\",\"proofs:create\",\"status:update\"]')").lastrowid
        admin=c.execute("INSERT INTO users(role_id,username,password_hash,display_name,email,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
            (admin_role,"admin",hash_password("Admin@12345"),"Maya Varma","admin@leomedflow.local",stamp,stamp)).lastrowid
        op_user=c.execute("INSERT INTO users(role_id,username,password_hash,display_name,email,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
            (operator_role,"operator",hash_password("Operator@12345"),"Arjun Nair","operator@leomedflow.local",stamp,stamp)).lastrowid
        op2_user=c.execute("INSERT INTO users(role_id,username,password_hash,display_name,email,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
            (operator_role,"operator2",hash_password("Operator2@12345"),"Neha Rao","neha@leomedflow.local",stamp,stamp)).lastrowid
        locations=[
            ("Central Warehouse","Plot 8, Medical Park","Ernakulam","Kerala","India",9.9816,76.2999),
            ("Lakeside Hospital","Marine Drive","Ernakulam","Kerala","India",9.9770,76.2760),
            ("North Clinic","MG Road","Thrissur","Kerala","India",10.5276,76.2144),
            ("Bengaluru Care Centre","Indiranagar","Bengaluru Urban","Karnataka","India",12.9784,77.6408),
        ]
        lids=[]
        for loc in locations: lids.append(c.execute("INSERT INTO locations(name,address,district,state,country,latitude,longitude,created_at) VALUES (?,?,?,?,?,?,?,?)",(*loc,stamp)).lastrowid)
        op1=c.execute("INSERT INTO operators(user_id,employee_code,phone,availability_status,location_id,max_concurrent_jobs,skills,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (op_user,"OP-001","+91 90000 11001","Available",lids[0],3,'["Cryotherapy","Laser"]',stamp,stamp)).lastrowid
        op2=c.execute("INSERT INTO operators(user_id,employee_code,phone,availability_status,location_id,max_concurrent_jobs,skills,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (op2_user,"OP-002","+91 90000 11002","Available",lids[2],2,'["Compression","Laser"]',stamp,stamp)).lastrowid
        customers=[]
        for row in [("CUS-001","Lakeside Hospital","care@lakeside.example","+91 484 400 1000",lids[1]),("CUS-002","North Clinic","ops@northclinic.example","+91 487 400 2000",lids[2]),("CUS-003","Bengaluru Care Centre","admin@bcc.example","+91 80 4000 3000",lids[3])]:
            customers.append(c.execute("INSERT INTO customers(code,name,email,phone,billing_location_id,service_location_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)",(row[0],row[1],row[2],row[3],row[4],row[4],stamp,stamp)).lastrowid)
        devices=[]
        for row in [("LMF-CRYO-1001","CryoPulse X2","Cryotherapy","Available",180000,today+timedelta(days=80)),("LMF-CRYO-1002","CryoPulse X2","Cryotherapy","Allocated",180000,today+timedelta(days=20)),("LMF-LASER-2101","LumaHeal Pro","Laser","In Use",245000,today+timedelta(days=120)),("LMF-COMP-3301","FlowPress 8","Compression","Maintenance",95000,today-timedelta(days=2)),("LMF-COMP-3302","FlowPress 8","Compression","Available",95000,today+timedelta(days=160)),("LMF-LASER-2102","LumaHeal Pro","Laser","Broken",245000,today+timedelta(days=40))]:
            devices.append(c.execute("INSERT INTO devices(serial_number,model,category,status,location_id,purchase_cost,maintenance_due_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",(row[0],row[1],row[2],row[3],lids[0],row[4],row[5].date().isoformat(),stamp,stamp)).lastrowid)
        consumables=[]
        for row in [("PAD-A-0001","PAD-CRYO","Cryotherapy Pad A","BAT-2604",18,"unit",850,"Available",today+timedelta(days=350)),("GEL-2608-01","GEL-LSR","Laser Conductive Gel","BAT-2608",4,"bottle",450,"Available",today+timedelta(days=200)),(None,"SLV-CMP","Compression Sleeve","BAT-2607",25,"unit",1200,"Available",today+timedelta(days=500)),("SENS-0042","SNS-TEMP","Temperature Sensor","BAT-2509",1,"unit",2800,"Allocated",today+timedelta(days=45))]:
            consumables.append(c.execute("INSERT INTO consumables(serial_number,sku,name,batch_number,quantity,unit,unit_cost,status,expiry_date,location_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8].date().isoformat(),lids[0],stamp,stamp)).lastrowid)
        statuses={"device":["Available","Allocated","In Use","Shipped","Received","Returned","Broken","Maintenance","Lost","Retired"],"consumable":["Available","Allocated","In Use","Consumed","Returned","Damaged","Expired","Lost"],"job":["Scheduled","Allocated","Shipped","Received","In Treatment","Awaiting Collection","Collected","Completed","Cancelled"]}
        colors=["#0f766e","#2878b5","#e9b44c","#497c90","#3b82f6","#22a06b","#e76f51","#b9382e","#64748b"]
        for entity,names in statuses.items():
            for i,name in enumerate(names): c.execute("INSERT INTO status_definitions(entity_type,name,color,terminal,sort_order) VALUES (?,?,?,?,?)",(entity,name,colors[i%len(colors)],int(name in ("Retired","Consumed","Completed","Cancelled")),i))
        c.execute("INSERT INTO custom_field_definitions(entity_type,field_key,label,field_type,options) VALUES ('device','calibration_certificate','Calibration certificate','text','[]')")
        scenarios=[
            ("QUO-202608-0001",customers[0],"Post-operative cryotherapy",4,today-timedelta(days=25),28000,4200,"Completed",op1,devices[0],consumables[0],25000,8800),
            ("QUO-202608-0002",customers[1],"Laser wound therapy",5,today-timedelta(days=2),42000,9000,"In Treatment",op2,devices[2],consumables[1],0,0),
            ("QUO-202608-0003",customers[0],"Cryotherapy recovery programme",7,today+timedelta(days=3),52000,12500,"Allocated",op1,devices[1],consumables[3],0,0),
            ("QUO-202608-0004",customers[2],"Compression therapy",3,today+timedelta(days=12),34000,7000,"Scheduled",op2,None,None,0,0),
            ("QUO-202608-0005",customers[2],"Laser rehabilitation",6,today-timedelta(days=75),65000,14500,"Completed",op2,devices[2],consumables[1],61000,15200),
            ("QUO-202608-0006",customers[1],"Compression recovery",2,today-timedelta(days=45),22000,5000,"Cancelled",op1,None,None,0,0),
        ]
        for idx,(qnum,cust,treatment,duration,start,total,cost,jstatus,operator,device,consumable,actual_revenue,actual_cost) in enumerate(scenarios,1):
            subtotal=round(total/1.05,2); qid=c.execute("INSERT INTO quotations(quote_number,customer_id,treatment,duration_days,treatment_start,subtotal,tax_rate,discount,total,cost_estimate,status,payment_status,line_items,created_by,approved_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (qnum,cust,treatment,duration,start.isoformat(),subtotal,5,0,total,cost,"Approved","Paid" if jstatus=="Completed" else "Unpaid",json.dumps([{"description":treatment,"quantity":1,"unit_price":subtotal}]),admin,stamp,stamp,stamp)).lastrowid
            end=start+timedelta(days=duration); jnum=f"JOB-202608-{idx:04d}"; jid=c.execute("INSERT INTO jobs(job_number,quotation_id,customer_id,operator_id,treatment,status,start_at,end_at,service_location_id,priority,revenue,estimated_cost,actual_cost,completed_at,cancelled_at,created_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (jnum,qid,cust,operator,treatment,jstatus,start.isoformat(),end.isoformat(),c.execute("SELECT service_location_id FROM customers WHERE id=?",(cust,)).fetchone()[0],"Normal",actual_revenue or total,cost,actual_cost,(end+timedelta(hours=8)).isoformat() if jstatus=="Completed" else None,stamp if jstatus=="Cancelled" else None,admin,stamp,stamp)).lastrowid
            c.execute("INSERT INTO schedules(job_id,operator_id,starts_at,ends_at,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",(jid,operator,start.isoformat(),end.isoformat(),"Completed" if jstatus=="Completed" else jstatus,stamp,stamp))
            c.execute("INSERT INTO invoices(invoice_number,quotation_id,job_id,customer_id,amount,tax,payment_status,paid_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)",(f"INV-202608-{idx:04d}",qid,jid,cust,total,round(total-subtotal,2),"Paid" if jstatus=="Completed" else "Unpaid",end.isoformat() if jstatus=="Completed" else None,stamp,stamp))
            for kind,rid,qty in [("device",device,1),("consumable",consumable,2)]:
                if not rid: continue
                astatus="Returned" if jstatus=="Completed" else ("Cancelled" if jstatus=="Cancelled" else ("In Use" if jstatus=="In Treatment" else "Allocated"))
                c.execute("INSERT INTO allocations(job_id,resource_type,resource_id,quantity,allocated_from,allocated_until,status,created_by,returned_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",(jid,kind,rid,qty,start.isoformat(),end.isoformat(),astatus,admin,end.isoformat() if jstatus=="Completed" else None,stamp,stamp))
                c.execute("INSERT INTO inventory_history(resource_type,resource_id,job_id,from_status,to_status,operator_id,notes,changed_by,created_at) VALUES (?,?,?,?,?,?,?,?,?)",(kind,rid,jid,"Available",astatus,operator,"Demo allocation history",admin,start.isoformat()))
            if jstatus=="Completed": c.execute("INSERT INTO collections(job_id,assigned_operator_id,location_id,scheduled_at,collected_at,status,notes,created_at,updated_at) VALUES (?,?,?,?,?,'Collected','Demo completed collection',?,?)",(jid,operator,c.execute("SELECT service_location_id FROM customers WHERE id=?",(cust,)).fetchone()[0],end.isoformat(),(end+timedelta(hours=8)).isoformat(),stamp,stamp))
            elif jstatus=="In Treatment": c.execute("INSERT INTO notifications(user_id,kind,title,message,job_id,created_at) VALUES (?,?,?,?,?,?)",(op2_user,"treatment","Treatment in progress",f"{jnum} completes {end.date().isoformat()}",jid,stamp))
        c.execute("UPDATE devices SET current_operator_id=?,current_job_id=(SELECT id FROM jobs WHERE job_number='JOB-202608-0002'),location_id=? WHERE id=?",(op2,lids[2],devices[2]))
        c.execute("UPDATE devices SET current_operator_id=?,current_job_id=(SELECT id FROM jobs WHERE job_number='JOB-202608-0003') WHERE id=?",(op1,devices[1]))
        c.execute("INSERT INTO maintenance(device_id,kind,status,scheduled_at,started_at,cost,notes,created_at,updated_at) VALUES (?,?,?, ?,?,?, ?,?,?)",(devices[3],"Preventive","In Progress",(today-timedelta(days=2)).isoformat(),(today-timedelta(days=2)).isoformat(),2500,"Annual pump and pressure calibration",stamp,stamp))
        c.execute("INSERT INTO audit_logs(actor_user_id,action,entity_type,entity_id,after_data,created_at) VALUES (?,?,?,?,?,?)",(admin,"seed","system","demo",json.dumps({"version":"1.0","records":"realistic workflow set"}),stamp))
        print("Seeded LEOMEDFLOW demo data")


if __name__ == "__main__": seed()
