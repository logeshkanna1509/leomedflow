#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
from pathlib import Path

from app import config
from app.db import migrate, rollback
from app.seed import seed
from app.server import run


def main() -> None:
    parser=argparse.ArgumentParser(description="LEOMEDFLOW management CLI")
    sub=parser.add_subparsers(dest="command",required=True)
    sub.add_parser("migrate"); rb=sub.add_parser("rollback"); rb.add_argument("--version",default="001_initial")
    sub.add_parser("seed"); serve=sub.add_parser("run"); serve.add_argument("--host",default=config.HOST); serve.add_argument("--port",type=int,default=config.PORT)
    args=parser.parse_args()
    if args.command=="migrate": print("Applied:",migrate() or "database already current")
    elif args.command=="rollback": rollback(version=args.version); print("Rolled back",args.version)
    elif args.command=="seed": seed()
    elif args.command=="run": run(args.host,args.port)


if __name__=="__main__": main()
